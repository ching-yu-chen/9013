﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CourseWinApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            //1.verify user name and password input
            if (string.IsNullOrWhiteSpace(this.UserName.Text) || string.IsNullOrWhiteSpace(this.Pwd.Password))
            {
                MessageBox.Show("User name or password can not be empty!");
                return;
            }

            //2. user is exist in database
          

            var win = new MenuWindow();
            win.Show();
            this.Close();
        }
    }
}
