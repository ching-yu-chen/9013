﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfLab.Models;

namespace WpfLab
{
    /// <summary>
    /// Interaction logic for BindLab2.xaml
    /// </summary>
    public partial class BindLab2 : Window
    {
        public BindLab2()
        {
            InitializeComponent();

            var p = new Person();
            p.Name = "IanChen";
            p.Email = "ianchen@mail.com";

            this.DataContext = p;
        }
    }
}
