﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfLab
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public int MyProperty { get; set; }

        private void Application_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            //持久化儲存
            //e.Exception.ToString();

            MessageBox.Show("系統發生錯誤", "系統錯誤", MessageBoxButton.OK, MessageBoxImage.Error);

            e.Handled = true;
        }

       

        //private void Application_Startup(object sender, StartupEventArgs e)
        //{
        //    var window = new MainWindow();
        //    window.Show();
        //}
    }

}
