﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfLab.Models;

namespace WpfLab
{
    /// <summary>
    /// Interaction logic for PassDataWindow2.xaml
    /// </summary>
    public partial class PassDataWindow2 : Window
    {
        public string PassData { get; set; }

        public PassDataWindow2()
        {
            InitializeComponent();
            //this.TextBlock1.Text = PassData;

            this.Loaded += PassDataWindow2_Loaded;
        }

        private void PassDataWindow2_Loaded(object sender, RoutedEventArgs e)
        {
            //this.TextBlock1.Text = PassData;
            this.TextBlock1.Text = this.DataContext as string;
        }

        //public PassDataWindow2(string passData)
        //{
        //    InitializeComponent();
        //    this.TextBlock1.Text = passData;
        //}

        ////傳遞物件
        //public PassDataWindow2(Person passData)
        //{
        //    InitializeComponent();
        //    this.TextBlock1.Text = passData.Email;
        //}
    }
}
