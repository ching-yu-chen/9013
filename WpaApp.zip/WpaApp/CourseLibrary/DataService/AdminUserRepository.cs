﻿using CourseLibrary.DataModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseLibrary.DataService
{
    public class AdminUserRepository
    {
        private readonly string _dbConnString;

        public AdminUserRepository(string dbConnString)
        {
            _dbConnString = dbConnString;
        }

        public AdminUserInfo GetAdminUser(string userName)
        {
            AdminUserInfo adminUserInfo = null;

            using (SqlConnection conn = new SqlConnection(_dbConnString))
            {
                var cmd = new SqlCommand("SELECT id,username,password,email FROM AdminUsers WHERE UserName = @UserName", conn);
                cmd.Parameters.AddWithValue("@UserName", userName);
                conn.Open();
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    adminUserInfo = new AdminUserInfo
                    {
                        Id = Guid.Parse(reader["id"].ToString()),
                        UserName = reader["username"].ToString(),
                        Password = reader["password"].ToString(),
                        Email = reader["email"].ToString()
                    };
                }
                reader.Close();
            }


            return adminUserInfo;
        }
    }
}
