﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models.OopInheritance
{
    public interface ILearnCourse
    {
        void AddLearn(string courseName);
        void RemoveLearn(string courseName);
    }

    public class Person
    {
        public Person(string name, string email, string mobile)
        {
            Name = name;
            Email = email;
            Mobile = mobile;
            Console.WriteLine($"Person 建構子被呼叫: {name}, {email}, {mobile}");
        }

        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
    }

    public class Student : Person, ILearnCourse
    {

        public string ClassName { get; set; }
        public List<string> Courses { get; set; }

        /*
         * 父類別有建構子時，子類別必須呼叫父類別的建構子
         * 在 C# 中，當子類別繼承自父類別時，必須呼叫父類別的建構子
         * 如果不寫 : base(...)，編譯器會嘗試呼叫父類別的無參數建構子，而導致錯誤
         */
        /*
         * 建構子多載 (Constructor Overloading) 的概念
         * 用途：建立只有基本資訊的學生物件（姓名、電子郵件、手機）
         */
        public Student(string name, string email, string mobile)
            : base(name, email, mobile) // 建構子串接：呼叫基底類別建構子
        {
            this.Courses = new List<string>();
            Console.WriteLine($"Student 建構子被呼叫: {name}, {email}, {mobile}");
        }

        /*
        * 建構子多載 (Constructor Overloading) 的概念
        * 用途：建立包含班級資訊的學生物件
        */
        public Student(string name, string email, string mobile, string className)
            : base(name, email, mobile) // 建構子串接：呼叫基底類別建構子
        {
            this.Courses = new List<string>();
            ClassName = className;
            Console.WriteLine($"Student 建構子被呼叫: {name}, {email}, {mobile}, {className}");
        }

        public void Study()
        {
            Console.WriteLine($"{Name} 正在學習 C# 繼承...");
        }

        public void AddLearn(string courseName)
        {
            this.Courses.Add(courseName);
            Console.WriteLine($"{Name} 已加入課程: {courseName}");
        }

        public void RemoveLearn(string courseName)
        {
            this.Courses.Remove(courseName);
            Console.WriteLine($"{Name} 已移除課程: {courseName}");
        }
    }

    public class Teacher : Person
    {
        public string Subject { get; set; }

        public Teacher(string name, string email, string mobile, string subject)
            : base(name, email, mobile)
        {
            Subject = subject;
            Console.WriteLine($"Teacher 建構子被呼叫: {name}, {email}, {mobile}, {subject}");
        }
    }

    // 需求摘要（2022/7/4）
    // 1) 線上影音課程與實體課，基本資料均具有 代碼(Code)、名稱(Name)、時數(Hours)
    //    實體課另外具有 上課時間(ClassTime) 及 上課地點(Location)
    // 2) 影音課程提供不限次數的回放（以介面表達能力）

    // 介面：提供「可回放」的能力
    public interface IReplayable
    {
        // 是否不限次數回放（本題需求：影音課程為 true）
        bool IsUnlimitedReplay { get; }
        // 觸發回放行為
        void Replay();
    }

    // 基底類別：所有課程的共通資料與行為
    public class CourseBase
    {
        protected CourseBase(string code, string name, int hours)
        {
            Code = code;
            Name = name;
            Hours = hours;
        }

        public string Code { get; private set; }
        public string Name { get; private set; }
        public int Hours { get; private set; }

        // 可被覆寫的描述
        public virtual string Describe()
        {
            return $"[{GetType().Name}] Code={Code}, Name={Name}, Hours={Hours}";
        }
    }

    // 線上影音課程：具備不限次數回放能力
    public class OnlineVideoCourse : CourseBase, IReplayable
    {
        public OnlineVideoCourse(string code, string name, int hours, string platform)
            : base(code, name, hours)
        {
            Platform = platform;
        }

        public string Platform { get; private set; }

        public bool IsUnlimitedReplay { get { return true; } }

        public void Replay()
        {
            Console.WriteLine($"回放《{Name}》於 {Platform}，不限次數播放中...");
        }

        //public override string Describe()
        //{
        //    return base.Describe() + $", Platform={Platform}, UnlimitedReplay={IsUnlimitedReplay}";
        //}
    }

    // 實體課程：具備時間與地點
    public class PhysicalCourse : CourseBase
    {
        public PhysicalCourse(string code, string name, int hours, DateTime classTime, string location)
            : base(code, name, hours)
        {
            ClassTime = classTime;
            Location = location;
        }

        public DateTime ClassTime { get; private set; }
        public string Location { get; private set; }

        public override string Describe()
        {
            //return $", Time={ClassTime:yyyy/MM/dd HH:mm}, Location={Location}";
            return base.Describe() + $", Time={ClassTime:yyyy/MM/dd HH:mm}, Location={Location}";
        }

        //public new string Describe()
        //{
        //    return $", Time={ClassTime:yyyy/MM/dd HH:mm}, Location={Location}";
        //    return base.Describe() + $", Time={ClassTime:yyyy/MM/dd HH:mm}, Location={Location}";
        //}
    }


    public class CourseWithExam
    {
        protected CourseWithExam(string code, string name)
        {
            Code = code;
            Name = name;
        }

        public string Code { get; }
        public string Name { get; }

        // 可被覆寫：不同課程類型有不同測驗方式
        public virtual void GetExamMethod()
        {
            Console.WriteLine("一般筆試");
        }

        // ===== 結業證書：多載（Overload）放在基底類別 =====
        public string IssueCertificate(string studentName)
            => BuildCertificate(studentName, null, null);

        public string IssueCertificate(string studentName, int score)
            => BuildCertificate(studentName, score, null);

        public string IssueCertificate(string studentName, string englishName)
            => BuildCertificate(studentName, null, englishName);

        public string IssueCertificate(string studentName, int score, string englishName)
            => BuildCertificate(studentName, score, englishName);

        private string BuildCertificate(string studentName, int? score, string englishName)
        {
            var title = $"《{Name}》結業證書";
            var lineName = $"學員：{studentName}" + (string.IsNullOrWhiteSpace(englishName) ? string.Empty : $"（{englishName}）");
            var lineCourse = $"課程代碼：{Code}";
            var lineScore = score.HasValue ? $"成績：{score.Value}" : null;

            return string.Join(Environment.NewLine, new[]
            {
                title,
                new string('-', title.Length),
                lineName,
                lineCourse,
                lineScore
            });
        }
    }

    // 1) 程式設計類課程：實作 + 單選題（Override）
    public class ProgrammingCourse : CourseWithExam
    {
        public ProgrammingCourse(string code, string name) : base(code, name) { }

        public override void GetExamMethod()
        {
            Console.WriteLine("實作 與 單選題");
        }
    }

    // 2) 語言類課程：聽力 + 閱讀（Override）
    public class LanguageCourse : CourseWithExam
    {
        public LanguageCourse(string code, string name) : base(code, name) { }

        public override void GetExamMethod()
        {
            Console.WriteLine("聽力 與 閱讀測驗");
        }
    }

}
