﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    public class CrptContent
    {
        /// <summary>
        /// RSA 加密後AESKey
        /// </summary>
        public string EncAesKey { get; set; }
        /// <summary>
        /// RSA 加密後AES IV
        /// </summary>
        public string EncAesIv { get; set; }
        /// <summary>
        /// AES 加密後內容
        /// </summary>
        public string EncMessageBase64 { get; set; }
    }

    public static class RsaMixAesDemo
    {
        /// <summary>
        /// 端到端示範：產生 AES，RSA 產生公私鑰，RSA 加密 AES Key/IV，AES 加密訊息，最後解回原文
        /// </summary>
        public static void Do()
        {
            var sourceStr = @"人工智慧產生內容（AIGC）則是 AI 的一個特定應用領域，它專注於使用 AI 建立新的、原創的內容。這可以包括文字、圖片、音樂、影片等各種形式的內容。";
            var packet = new CrptContent(); // 傳輸封包（只傳遞密文與被 RSA 加密的 AES Key/IV）

            using (var aes = Aes.Create())
            using (var rsa = new RSACryptoServiceProvider(2048))
            {
                // 匯出 RSA 金鑰（XML，相容 .NET Framework）
                var publicKeyXml = rsa.ToXmlString(false);
                var privateKeyXml = rsa.ToXmlString(true);

                var aesKey = aes.Key; // 預設 256-bit
                var aesIv = aes.IV;   // 128-bit，隨機

                Console.WriteLine("\n====== Encryptor 端 ======\n");
                Console.WriteLine($"AES Key (Base64): {Convert.ToBase64String(aesKey)}");
                Console.WriteLine($"AES IV  (Base64): {Convert.ToBase64String(aesIv)}");

                // 1) RSA 用公鑰加密 AES Key/IV
                rsa.FromXmlString(publicKeyXml);

                // RSA 加密 AES Key
                var cipherKey = rsa.Encrypt(aesKey, true);
                packet.EncAesKey = Convert.ToBase64String(cipherKey);

                // RSA 加密 AES IV
                var cipherIv = rsa.Encrypt(aesIv, true);
                packet.EncAesIv = Convert.ToBase64String(cipherIv);

                Console.WriteLine($"EncAesKey (Base64) => {packet.EncAesKey}");
                Console.WriteLine($"EncAesIv  (Base64) => {packet.EncAesIv}");

                // 2) AES 加密訊息（輸出 Base64）
                var data = Encoding.UTF8.GetBytes(sourceStr);
                using (var aesEncryptor = aes.CreateEncryptor(aesKey, aesIv))
                {
                    var cipher = aesEncryptor.TransformFinalBlock(data, 0, data.Length);
                    packet.EncMessageBase64 = Convert.ToBase64String(cipher);
                }
                Console.WriteLine($"EncMessageBase64      => {packet.EncMessageBase64}");


                Console.WriteLine("\n====== Decryptor 端 ======\n");
                
                // 3) RSA 用私鑰解出 AES Key/IV
                rsa.FromXmlString(privateKeyXml);

                // RSA 解密 AES Key
                var encKeyBytes = Convert.FromBase64String(packet.EncAesKey);
                var decAesKey = rsa.Decrypt(encKeyBytes, true);

                // RSA 解密 AES IV
                var encIvBytes = Convert.FromBase64String(packet.EncAesIv);
                var decAesIv = rsa.Decrypt(encIvBytes, true);

                Console.WriteLine($"解密後 AES Key 相符 => {Convert.ToBase64String(decAesKey) == Convert.ToBase64String(aesKey)}");
                Console.WriteLine($"解密後 AES IV  相符 => {Convert.ToBase64String(decAesIv) == Convert.ToBase64String(aesIv)}");

                // 4) AES 解密訊息
                var cipherBytes = Convert.FromBase64String(packet.EncMessageBase64);
                using (var aesDecryptor = aes.CreateDecryptor(decAesKey, decAesIv))
                {
                    var plainBytes = aesDecryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
                    var plain = Encoding.UTF8.GetString(plainBytes);

                    Console.WriteLine("\n====== 解密結果 ======");
                    Console.WriteLine($"明文 => {plain}");
                    Console.WriteLine($"與來源一致 => {plain == sourceStr}");
                }
            }
        }
    }
}
