﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// 商品類別
    /// </summary>
    internal class Product
    {
        // 商品唯一識別碼(唯讀)
        /*
         * 何時該用唯讀屬性？
         * 識別碼（Id）：不應在物件生命週期中變更。
         * 不可重複的商業邏輯。
         * 只在建構子初始化一次的值。
         */
        public Guid Id { get; }
        // 商品代碼
        public string Code { get; set; }
        // 商品名稱
        public string Name { get; set; }
        // 商品價格
        public int Price { get; private set; }

        //private int _price; // 價格
        //public int Price
        //{
        //    get
        //    {
        //        return _price;
        //    }
        //    set
        //    {
        //        if (value < 0 || value >= 1000)
        //        {
        //            throw new ArgumentOutOfRangeException();
        //        }
        //        _price = value;
        //    }
        //}

        // 製造商屬性
        public Manufacturer Manufacturer { get; set; }

        public Product(string code, string name, int price)
        {
            this.Id = Guid.NewGuid(); // 自動生成唯一識別碼
            this.Code = code;
            this.Name = name;
            this.Price = price;
        }

        public Product(Guid id, string code, string name, int price)
        {
            this.Id = id;
            this.Code = code;
            this.Name = name;
            this.Price = price;
        }

        public void Display()
        {
            Console.WriteLine($"商品代碼: {Code}, 商品名稱: {Name}, 商品價格: {Price}");
        }

        public void SetPrice(int price)
        {
            if (price < 0 || price >= 1000)
            {
                throw new ArgumentException("價格不能為負數 or >=1000");
            }
            this.Price = price;

        }
    }

    /// <summary>
    /// 製造商 Manufacturer 類別
    /// </summary>
    internal class Manufacturer
    {
        public string Name { get; }
        public string Tel { get; }
        public string Email { get; }

        public Manufacturer(string name, string tel, string email)
        {
            Name = name;
            Tel = tel;
            Email = email;
        }
    }

}
