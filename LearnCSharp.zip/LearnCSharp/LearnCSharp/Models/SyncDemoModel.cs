﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// 同步版本示範：用 Thread.Block（Task.Delay(...).Wait()）模擬 I/O 等待
    /// 教學重點：同步作業會阻塞目前執行緒，總時間為工作時間的總和。
    /// </summary>
    public static class SyncDemoModel
    {
        /// <summary>
        /// 同步煮咖啡（阻塞 3 秒）
        /// </summary>
        public static void Coffee()
        {
            Task.Delay(3000).Wait();
            Console.WriteLine($"coffee OK {DateTime.Now}");
        }

        /// <summary>
        /// 同步煎蛋（阻塞 3 秒）
        /// </summary>
        public static void Eggs()
        {
            Task.Delay(3000).Wait();
            Console.WriteLine($"Eggs OK {DateTime.Now}");
        }

        /// <summary>
        /// 同步烤吐司（阻塞 3 秒）
        /// </summary>
        public static void Bread()
        {
            Task.Delay(3000).Wait();
            Console.WriteLine($"Bread OK {DateTime.Now}");
        }
    }

    /*
     * 在宣告方法時加上關鍵字 async，表示它是個非同步方法，並且應該要使用關鍵字 await 來等待非同步工作的結果
     * 碰到 await 時，立刻返回呼叫端（eg : Main 函式），並傳回一個 Task 物件。
     * await 之前的程式碼是一個同步執行的執行緒，await 敘述之後的程式碼則為另一個同步執行的執行緒
     * (1)碰到 await 時，流程會立刻返回呼叫端，await 之後的程式碼則會暫時保留
     * (2)當 await 所等待的工作完成之後，才會恢復繼續執行後面的程式碼
     * async 的非同步方法裡面可以有一個或多個的 await 工作
     * Task： 沒有回傳值
     * Task<T> ：有回傳值
     * async 方法，不可使用 ref  或 out 修飾詞做為傳入參數
     */
    /// <summary>
    /// 非同步版本示範：使用 async/await 模擬 I/O 等待不阻塞執行緒
    /// 教學重點：
    /// - async 標註方法，回傳型別為 Task 或 Task<T>
    /// - await 碰到待等待的 Task 時，會「讓出執行緒」直到作業完成
    /// - 非同步不代表多執行緒；但能提升併發度與 UI 回應度
    /// </summary>
    public static class AsyncDemoModel
    {
        /// <summary>
        /// 非同步煮咖啡（延遲 3 秒），不阻塞執行緒
        /// </summary>
        public static async Task CoffeeAsync()
        {
            await Task.Delay(3000); // 模擬花費的時間
            Console.WriteLine($"咖啡已完成！{DateTime.Now}");
        }

        public static async Task EggsAsync()
        {
            await Task.Delay(3000); // 模擬花費的時間
            Console.WriteLine($"Egg已完成！{DateTime.Now}");
        }

        public static async Task BreadAsync()
        {
            await Task.Delay(3000); // 模擬花費的時間
            Console.WriteLine($"Bread已完成！{DateTime.Now}");
        }

        public static async Task<long> SimulateHeavyWorkAsync()
        {
            Console.WriteLine("開始執行長時間運算...");

            // 這裡使用Task.Run因為是CPU/IO密集型工作，不會造成UI凍結
            // Task.Delay(3000)則是原本就是task非同步方法,所以不需要再包一層Task.Run
            var result = await Task.Run(() =>
            {
                // 模擬複雜計算
                long sum = 0;
                for (int i = 0; i < 100000000; i++)
                {
                    sum += i;
                }
                return sum;
            });

            Console.WriteLine($"計算完成，結果: {result}");
            return result;
        }

        public static long SimulateHeavyWork()
        {
            // 模擬複雜計算
            long sum = 0;
            for (int i = 0; i < 100000000; i++)
            {
                sum += i;
            }
            return sum;
        }

    }
}
