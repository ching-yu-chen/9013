﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// 課程記錄類別
    /// </summary>
    internal class CourseRecord
    {
        public string CourseCode { get; set; }    // 課程代碼
        public string CourseName { get; set; }    // 課程名稱
        public int Hours { get; set; }            // 上課時數
        public string Location { get; set; }      // 上課地點


        public CourseRecord(string courseCode, string courseName, int hours, string location)
        {
            CourseCode = courseCode;
            CourseName = courseName;
            Hours = hours;
            Location = location;
        }
    }

    public class CourseData
    {
        public string Category { get; set; }
        public string Name { get; set; }
        public string Teacher { get; set; }
        public int Hours { get; set; }
    }

    public class CourseDataLite
    {
        public string Name { get; set; }
        public string Teacher { get; set; }
    }
}
