﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /*
    雜湊的主要用途：
    密碼儲存
    不儲存原始密碼，只儲存雜湊值
    加入鹽值(Salt)增加安全性
    使用強度足夠的演算法（如PBKDF2, BCrypt）

    雜湊的重要特性：
    *單向性
    無法從雜湊值反推原始資料
    即使微小的輸入改變也會產生完全不同的雜湊值

    *確定性
    相同輸入總是產生相同雜湊值
    不同輸入極少機會產生相同雜湊值（碰撞）

    SHA-256 (推薦)
    256位元雜湊值
    目前被廣泛使用
    安全性高

    SHA-512 (推薦)
    512位元雜湊值
    更高的安全性
    適用於關鍵資料


    將雜湊比喻為「資料的指紋」是非常貼切的：
    指紋的特性與雜湊的對應：

    唯一性

    指紋：每個人的指紋都是獨特的
    雜湊：不同的輸入資料會產生不同的雜湊值


    固定大小

    指紋：每個指紋的大小和形狀範圍都是固定的
    雜湊：無論輸入資料多大，雜湊值的長度都是固定的

    SHA-256 總是 256 位元
    SHA-512 總是 512 位元


    不可逆性

    指紋：無法從指紋還原出一個完整的人
    雜湊：無法從雜湊值還原出原始資料

    */
    public static class HashDemo
    {
        //新的SHA256寫法
        public static void SHA256Demo(string sourceStr)
        {
            var result = string.Empty;

            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] hashBytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(sourceStr));
                //byte[] to base64 string
                result = Convert.ToBase64String(hashBytes);
                Console.WriteLine("Hash Value：");
                Console.WriteLine(result);
            }
        }

        //新的SHA512寫法
        public static void SHA512Demo(string sourceStr)
        {
            var result = string.Empty;
            using (SHA512 sha512Hash = SHA512.Create())
            {
                byte[] hashBytes = sha512Hash.ComputeHash(Encoding.UTF8.GetBytes(sourceStr));
                //byte[] to base64 string
                result = Convert.ToBase64String(hashBytes);
                Console.WriteLine("Hash Value：");
                Console.WriteLine(result);
            }
        }

        public static void PwdSHA256Demo(string pwdStr, string salt)
        {
            //單純加鹽：
            // password + salt → SHA256 → hash
            // (只執行一次)
            var result = string.Empty;
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] hashBytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(pwdStr + salt.ToUpper()));
                //byte[] to base64 string
                result = Convert.ToBase64String(hashBytes);

            }
            Console.WriteLine($"Hash Value：{result}");
        }

        //PBKDF2使用自訂義的 salt
        public static void PwdPBKDF2Hash(string password, string saltValue)
        {
            /*
            PBKDF2：
            password + salt → SHA256 → hash → SHA256 → hash → SHA256 → ...
            (重複執行100,000次)
            */
            //PBKDF2 的輸出長度，與 HashAlgorithmName 並沒有「必須相等」的直接關係。
            const int HashSize = 32; //256bits(1 byte = 8 bits,32 bytes = 32 * 8 = 256 bits)
            var result = string.Empty;
            byte[] salt = Encoding.UTF8.GetBytes(saltValue);
            //進行多次迭代（如10萬次）的雜湊計算
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 100000, HashAlgorithmName.SHA256))
            {
                byte[] hash = pbkdf2.GetBytes(HashSize);
                result = Convert.ToBase64String(hash);

                Console.WriteLine($"密碼: {password}");
                Console.WriteLine($"鹽值: {Convert.ToBase64String(salt)}");
                Console.WriteLine($"雜湊值: {Convert.ToBase64String(hash)}");
                Console.WriteLine($"迭代次數: 100,000 \n\n");
            }
        }

        //PBKDF2使用隨機的 salt
        public static void PwdPBKDF2Hash(string password)
        {
            /*
            PBKDF2：
            password + salt → SHA256 → hash → SHA256 → hash → SHA256 → ...
            (重複執行100,000次)
            */
            //PBKDF2 的輸出長度，與 HashAlgorithmName 並沒有「必須相等」的直接關係。
            const int HashSize = 32; //256bits(1 byte = 8 bits,32 bytes = 32 * 8 = 256 bits)
            var result = string.Empty;
            //進行多次迭代（如10萬次）的雜湊計算,salt size =16
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, 16, 100000, HashAlgorithmName.SHA256))
            {
                byte[] hash = pbkdf2.GetBytes(HashSize);
                byte[] salt = pbkdf2.Salt;  //要自行保存，以便後續驗證密碼時，可以採用相同的slat
                result = Convert.ToBase64String(hash);

                Console.WriteLine($"密碼: {password}");
                Console.WriteLine($"鹽值: {Convert.ToBase64String(salt)}");
                Console.WriteLine($"雜湊值: {Convert.ToBase64String(hash)}");
                Console.WriteLine($"迭代次數: 100,000 \n\n");
            }
        }
    }


    public static class Base64Demo
    {
        /*
        Base64不是加密，只是編碼，可以將二進位資料轉換為文本格式，方便傳輸和存儲。
        可以輕易解碼，不要用於敏感資料保護。

        為什麼需要Base64：

        跨系統資料傳輸

        不同系統可能對二進位資料有不同的處理方式
        某些系統可能無法直接處理二進位資料
        Base64可以確保資料在傳輸過程中不會被破壞

        文字協定的限制

        電子郵件協定(SMTP)最初只能傳輸ASCII字符
        URL不能包含特殊字符
        XML/JSON等文字格式不能直接包含二進位資料


        常見應用場景

        圖片嵌入HTML/CSS
        在JSON中傳輸二進位資料
        電子郵件附件編碼
        API傳輸檔案
        數位簽章

        Base64 字符集組成（64個字符）
        A-Z (26個字符)
        a-z (26個字符)
        0-9 (10個字符)
        +, / (2個字符)
        = (用於補位)

        */
        public static void Do(string sourceStr)
        {
            /*
             * 要跨平台/跨語言/網路與檔案交換：選 UTF-8
             * Web/JSON/XML/REST API/資料庫欄位：選 UTF-8
             * 僅限 Windows/Win32 API/COM/Registry/Office Interop：可用 UTF-16(.NET 的 Encoding.Unicode)
             * 內容主要是英文或混合語系：UTF-8 通常更省空間
             * 
             * 關鍵觀念：
             * Unicode 是字元集，不是編碼；
             * UTF-8、UTF-16、UTF-32 是把 Unicode 編碼成位元組的方式。
             * .NET 的 string 內部使用 UTF-16
             * 在 .NET 中
             * —　Encoding.UTF8 = UTF-8
             * —　Encoding.Unicode = UTF-16 (UTF-16 Little Endian)
             * —　現代生態（Web、API、跨平台）以 UTF-8 為標準事實上的預設。
             */
            var ctbyte = Encoding.UTF8.GetBytes(sourceStr);
            var base64String = Convert.ToBase64String(ctbyte);
            Console.WriteLine("Base64 String：");
            Console.WriteLine(base64String);
            Console.WriteLine("\n\n");
            byte[] data = Convert.FromBase64String(base64String);
            string originalString = Encoding.UTF8.GetString(data);

            Console.WriteLine("還原後的字串：");
            Console.WriteLine(originalString);
        }
    }
}
