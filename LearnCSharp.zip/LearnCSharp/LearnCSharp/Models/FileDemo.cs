﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    public static class FileDemo
    {
        public static void Exec()
        {
            try
            {
                // 建構檔案路徑 - 使用 Path.Combine 可確保跨平台相容性Resource\myfile.txt
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "myfile.txt");

                //Console.WriteLine($"正在讀取檔案: {filePath}");

                //// 方法1: 一次讀取整個檔案內容
                //string text = File.ReadAllText(filePath);
                //Console.WriteLine("【方法1 - ReadAllText】讀取整個檔案:");
                //Console.WriteLine($"檔案內容: {text}");

                //Console.WriteLine("\n" + new string('=', 50));

                //// 方法2: 逐行讀取檔案
                //string[] lines = File.ReadAllLines(filePath);
                //Console.WriteLine("【方法2 - ReadAllLines】逐行讀取:");
                //for (int i = 0; i < lines.Length; i++)
                //{
                //    Console.WriteLine($"第 {i + 1} 行: {lines[i]}");
                //}


                Console.WriteLine("【檔案寫入展示】");
                Console.WriteLine($"目標檔案: {filePath}");

                // 確保目錄存在
                string directory = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                    Console.WriteLine($"已建立目錄: {directory}");
                }

                // 方法1: 使用 WriteAllLines 寫入多行內容
                string[] lines = {
                    "【WriteAllLines 範例】類別支援繼承的概念",
                    "類別和結構可以繼承多個介面。繼承介面表示型別會實作介面中定義的所有方法",
                    "所有的方法、欄位、常數、屬性和事件都必須在型別內宣告"
                };

                File.WriteAllLines(filePath, lines, Encoding.UTF8); // 指定編碼為 UTF-8
                Console.WriteLine("✓ 使用 WriteAllLines 寫入完成");

                // 方法2: 使用 WriteAllText 寫入大段文字（這會覆蓋原有內容）
                string content = @"【WriteAllText 範例】
人工智慧（AI）是一種涵蓋範圍很廣的技術，它包括機器學習、深度學習、自然語言處理等多種子領域。
AIGC 則是 AI 的一個特定應用領域，它專注於使用 AI 建立新的、原創的內容。

這個檔案展示了 C# 檔案寫入操作的不同方式。";

                File.WriteAllText(filePath, content, Encoding.UTF8);
                Console.WriteLine("✓ 使用 WriteAllText 覆蓋寫入完成");

                // 方法3: 附加內容到檔案末尾（不覆蓋原有內容）
                string appendContent = "\n\n【附加內容】這行是使用 AppendAllText 方法附加的內容。";
                File.AppendAllText(filePath, appendContent, Encoding.UTF8);
                Console.WriteLine("✓ 使用 AppendAllText 附加內容完成");

                Console.WriteLine("所有檔案寫入操作已完成！");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("錯誤：檔案不存在，請確認檔案路徑是否正確。");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有讀取/寫入檔案的權限。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"檔案讀取發生錯誤: {ex.Message}");
            }

        }

        /// <summary>
        /// 基本檔案操作：檢查存在、複製、移動、刪除
        /// 這個方法示範檔案管理的常用操作
        /// </summary>
        public static void Exec2()
        {
            Console.WriteLine("【基本檔案操作展示】");

            // 定義檔案路徑
            string sourceFile = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "myfile.txt");
            string copyFile = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "myfile_copy.txt");
            string moveFile = Path.Combine(Directory.GetCurrentDirectory(), "myfile_moved.txt");

            try
            {
                // 1. 檢查檔案是否存在
                Console.WriteLine($"\n1. 檢查檔案是否存在:");
                bool sourceExists = File.Exists(sourceFile);
                Console.WriteLine($"   來源檔案 {Path.GetFileName(sourceFile)} 存在: {sourceExists}");

                if (!sourceExists)
                {
                    Console.WriteLine("   來源檔案不存在，建立範例檔案...");
                    // 確保目錄存在
                    Directory.CreateDirectory(Path.GetDirectoryName(sourceFile));
                    File.WriteAllText(sourceFile, "這是一個範例檔案，用來展示檔案操作。");
                    Console.WriteLine("   ✓ 範例檔案已建立");
                }

                // 2. 複製檔案
                Console.WriteLine($"\n2. 複製檔案:");
                File.Copy(sourceFile, copyFile, overwrite: true); // overwrite: true 允許覆蓋現有檔案
                Console.WriteLine($"   ✓ 已複製檔案: {Path.GetFileName(sourceFile)} → {Path.GetFileName(copyFile)}");

                // 3. 檢查複製後的檔案
                Console.WriteLine($"   複製的檔案存在: {File.Exists(copyFile)}");

                // 4. 讀取檔案大小資訊
                FileInfo sourceInfo = new FileInfo(sourceFile);
                FileInfo copyInfo = new FileInfo(copyFile);
                Console.WriteLine($"   來源檔案大小: {sourceInfo.Length} bytes");
                Console.WriteLine($"   複製檔案大小: {copyInfo.Length} bytes");

                // 5. 移動檔案（注意：移動會刪除原始檔案）
                Console.WriteLine($"\n3. 移動檔案:");
                if (File.Exists(moveFile)) File.Delete(moveFile);
                File.Move(copyFile, moveFile);
                Console.WriteLine($"   ✓ 已移動檔案: {Path.GetFileName(copyFile)} → {Path.GetFileName(moveFile)}");
                Console.WriteLine($"   原複製檔案存在: {File.Exists(copyFile)}");
                Console.WriteLine($"   移動後檔案存在: {File.Exists(moveFile)}");

                // 6. 刪除檔案
                Console.WriteLine($"\n4. 刪除檔案:");
                if (File.Exists(moveFile))
                {
                    File.Delete(moveFile);
                    Console.WriteLine($"   ✓ 已刪除檔案: {Path.GetFileName(moveFile)}");
                    Console.WriteLine($"   刪除後檔案存在: {File.Exists(moveFile)}");
                }

                Console.WriteLine("\n所有基本檔案操作展示完成！");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine($"錯誤：檔案不存在 - {ex.Message}");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"錯誤：權限不足 - {ex.Message}");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"檔案操作發生錯誤: {ex.Message}");
            }
        }
    }

    public static class FileInfoAccessDemo
    {
        /// <summary>
        /// 展示使用 FileInfo 讀取檔案和取得檔案詳細資訊
        /// FileInfo 相較於 File 類別的優勢：
        /// 1. 物件導向設計，可重複使用同一個物件實例
        /// 2. 提供豐富的檔案屬性資訊
        /// 3. 適合需要多次操作同一檔案的場景
        /// </summary>
        public static void Exec()
        {
            Console.WriteLine("【FileInfo 檔案讀取與資訊展示】");

            // 建立 FileInfo 物件
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "myfile.txt");
            FileInfo fileInfo = new FileInfo(filePath);

            try
            {
                // 展示檔案基本資訊
                Console.WriteLine("=== 檔案基本資訊 ===");
                Console.WriteLine($"檔案名稱: {fileInfo.Name}");
                Console.WriteLine($"完整路徑: {fileInfo.FullName}");
                Console.WriteLine($"目錄路徑: {fileInfo.DirectoryName}");
                Console.WriteLine($"副檔名: {fileInfo.Extension}");
                Console.WriteLine($"檔案大小: {fileInfo.Length} bytes ({fileInfo.Length / 1024.0:F2} KB)");

                // 展示檔案時間資訊
                Console.WriteLine("\n=== 檔案時間資訊 ===");
                Console.WriteLine($"建立時間: {fileInfo.CreationTime:yyyy-MM-dd HH:mm:ss}");
                Console.WriteLine($"最後存取時間: {fileInfo.LastAccessTime:yyyy-MM-dd HH:mm:ss}");
                Console.WriteLine($"最後修改時間: {fileInfo.LastWriteTime:yyyy-MM-dd HH:mm:ss}");

                // 展示檔案屬性
                Console.WriteLine("\n=== 檔案屬性 ===");
                Console.WriteLine($"檔案存在: {fileInfo.Exists}");
                Console.WriteLine($"是否為唯讀: {(fileInfo.Attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly}");
                Console.WriteLine($"是否為隱藏檔案: {(fileInfo.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden}");
                Console.WriteLine($"是否為系統檔案: {(fileInfo.Attributes & FileAttributes.System) == FileAttributes.System}");

                // 檢查檔案是否存在並讀取內容
                if (fileInfo.Exists)
                {
                    Console.WriteLine("\n=== 檔案內容 ===");

                    // 方法1: 使用 StreamReader 逐行讀取（推薦用於大檔案）
                    Console.WriteLine("【使用 StreamReader 逐行讀取】:");
                    using (StreamReader reader = fileInfo.OpenText()) // OpenText() 是 FileInfo 特有的方法
                    {
                        string line;
                        int lineNumber = 1;
                        while ((line = reader.ReadLine()) != null)
                        {
                            Console.WriteLine($"第 {lineNumber:D2} 行: {line}");
                            lineNumber++;
                        }
                    }


                    // 方法2: 一次讀取全部內容（適用於小檔案）
                    Console.WriteLine("\n【一次讀取全部內容】:");
                    using (StreamReader reader = fileInfo.OpenText())
                    {
                        string allContent = reader.ReadToEnd();
                        Console.WriteLine($"檔案總內容長度: {allContent.Length} 字元");
                        Console.WriteLine("前 100 字元預覽:");
                        Console.WriteLine(allContent.Length > 100 ? allContent.Substring(0, 100) + "..." : allContent);
                    }
                }
                else
                {
                    Console.WriteLine($"檔案 {filePath} 不存在。");
                    Console.WriteLine("建立範例檔案進行展示...");

                    // 確保目錄存在
                    fileInfo.Directory.Create();

                    // 建立範例檔案
                    string sampleContent = @"這是使用 FileInfo 建立的範例檔案。
FileInfo 類別提供了豐富的檔案操作功能。
建立時間: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + @"

FileInfo 的主要優勢：
1. 物件導向設計
2. 提供詳細的檔案屬性資訊
3. 適合重複操作同一檔案";

                    File.WriteAllText(filePath, sampleContent, Encoding.UTF8);
                    Console.WriteLine("✓ 範例檔案已建立，請重新執行此方法查看結果。");
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有存取檔案的權限。");
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine("錯誤：指定的目錄不存在。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"檔案讀取發生錯誤: {ex.Message}");
            }
        }

        public static void Exec2()
        {
            Console.WriteLine("【FileInfo 檔案寫入操作展示】");

            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "fileinfo_demo.txt");
            FileInfo fileInfo = new FileInfo(filePath);

            try
            {
                // 確保目錄存在
                if (!fileInfo.Directory.Exists)
                {
                    fileInfo.Directory.Create();
                    Console.WriteLine($"✓ 已建立目錄: {fileInfo.Directory.FullName}");
                }

                Console.WriteLine($"目標檔案: {fileInfo.FullName}");

                // 準備寫入的資料
                string[] lines = {
                    "【FileInfo 寫入展示】",
                    "這是使用 FileInfo.CreateText() 建立的檔案",
                    "FileInfo 提供了更精細的檔案操作控制",
                    "建立時間: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                // 方法1: 使用 CreateText() 建立全新檔案（會覆蓋現有檔案）
                Console.WriteLine("\n1. 使用 CreateText() 建立新檔案:");
                using (StreamWriter writer = fileInfo.CreateText())
                {
                    foreach (string line in lines)
                    {
                        writer.WriteLine(line);
                    }
                    writer.WriteLine(); // 空行分隔
                    writer.WriteLine("這個檔案使用 FileInfo.CreateText() 方法建立。");
                }
                Console.WriteLine("✓ 檔案建立完成");

                // 重新整理 FileInfo 以取得最新資訊
                fileInfo.Refresh();
                Console.WriteLine($"   檔案大小: {fileInfo.Length} bytes");
                Console.WriteLine($"   修改時間: {fileInfo.LastWriteTime:yyyy-MM-dd HH:mm:ss}");

                // 方法2: 使用 AppendText() 附加內容到檔案末尾
                Console.WriteLine("\n2. 使用 AppendText() 附加內容:");
                string[] appendLines = {
                    "",
                    "=== 附加的內容 ===",
                    "這些內容使用 FileInfo.AppendText() 方法附加",
                    "AppendText() 不會覆蓋原有內容",
                    "附加時間: " + DateTime.Now.ToString("HH:mm:ss"),
                    "檔案操作展示完成！"
                };

                using (StreamWriter writer = fileInfo.AppendText())
                {
                    foreach (string line in appendLines)
                    {
                        writer.WriteLine(line);
                    }
                }
                Console.WriteLine("✓ 內容附加完成");

                // 再次重新整理並顯示最終檔案資訊
                fileInfo.Refresh();
                Console.WriteLine($"   最終檔案大小: {fileInfo.Length} bytes");
                Console.WriteLine($"   最終修改時間: {fileInfo.LastWriteTime:yyyy-MM-dd HH:mm:ss}");

                // 驗證寫入結果 - 讀取並顯示檔案內容
                Console.WriteLine("\n3. 驗證寫入結果:");
                using (StreamReader reader = fileInfo.OpenText())
                {
                    string content = reader.ReadToEnd();
                    Console.WriteLine("檔案最終內容:");
                    Console.WriteLine(new string('-', 50));
                    Console.WriteLine(content);
                    Console.WriteLine(new string('-', 50));
                }

                Console.WriteLine("FileInfo 檔案寫入操作展示完成！");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有寫入檔案的權限。");
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine("錯誤：指定的目錄不存在。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"檔案寫入發生錯誤: {ex.Message}");
            }
        }

        /// <summary>
        /// 展示使用 FileInfo 進行檔案複製和移動操作
        /// FileInfo 提供了更直觀的物件導向檔案操作方式
        /// </summary>
        public static void Exec3()
        {
            Console.WriteLine("【FileInfo 檔案複製與移動操作展示】");

            string sourceFile = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "fileinfo_demo.txt");
            string copyFile = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "fileinfo_copy.txt");
            string moveFile = Path.Combine(Directory.GetCurrentDirectory(), "fileinfo_moved.txt");

            try
            {
                // 建立來源檔案的 FileInfo 物件
                FileInfo sourceFileInfo = new FileInfo(sourceFile);

                Console.WriteLine($"來源檔案: {sourceFileInfo.Name}");
                Console.WriteLine($"完整路徑: {sourceFileInfo.FullName}");

                // 確保來源檔案存在
                if (!sourceFileInfo.Exists)
                {
                    Console.WriteLine("來源檔案不存在，建立範例檔案...");
                    sourceFileInfo.Directory.Create(); // 確保目錄存在

                    using (StreamWriter writer = sourceFileInfo.CreateText())
                    {
                        writer.WriteLine("這是用於 FileInfo 複製和移動展示的範例檔案");
                        writer.WriteLine("建立時間: " + DateTime.Now);
                        writer.WriteLine("檔案大小會在操作過程中顯示");
                    }
                    sourceFileInfo.Refresh(); // 重新整理以取得最新資訊
                    Console.WriteLine("✓ 範例檔案已建立");
                }

                // 顯示來源檔案資訊
                Console.WriteLine($"來源檔案大小: {sourceFileInfo.Length} bytes");
                Console.WriteLine($"來源檔案修改時間: {sourceFileInfo.LastWriteTime:yyyy-MM-dd HH:mm:ss}");

                // 1. 檔案複製操作
                Console.WriteLine("\n=== 檔案複製操作 ===");
                FileInfo copiedFileInfo = sourceFileInfo.CopyTo(copyFile, overwrite: true);
                Console.WriteLine($"✓ 檔案已複製到: {copiedFileInfo.FullName}");
                Console.WriteLine($"複製檔案大小: {copiedFileInfo.Length} bytes");
                Console.WriteLine($"複製檔案修改時間: {copiedFileInfo.LastWriteTime:yyyy-MM-dd HH:mm:ss}");

                // 驗證複製是否成功
                bool copySuccess = sourceFileInfo.Length == copiedFileInfo.Length;
                Console.WriteLine($"複製驗證: {(copySuccess ? "成功" : "失敗")} - 檔案大小相符: {copySuccess}");

                // 2. 檔案移動操作
                Console.WriteLine("\n=== 檔案移動操作 ===");
                Console.WriteLine($"將複製的檔案移動到: {moveFile}");

                // 注意：MoveTo 會修改原 FileInfo 物件的路徑資訊
                string originalPath = copiedFileInfo.FullName;
                if (File.Exists(moveFile)) File.Delete(moveFile);
                copiedFileInfo.MoveTo(moveFile);

                Console.WriteLine($"✓ 檔案已從 {Path.GetFileName(originalPath)} 移動到 {copiedFileInfo.Name}");
                Console.WriteLine($"移動後檔案路徑: {copiedFileInfo.FullName}");
                Console.WriteLine($"原複製檔案存在: {File.Exists(copyFile)}");
                Console.WriteLine($"移動後檔案存在: {copiedFileInfo.Exists}");

                // 3. 展示檔案屬性比較
                Console.WriteLine("\n=== 檔案屬性比較 ===");
                Console.WriteLine($"來源檔案 vs 移動後檔案:");
                Console.WriteLine($"檔案大小: {sourceFileInfo.Length} vs {copiedFileInfo.Length}");
                Console.WriteLine($"建立時間: {sourceFileInfo.CreationTime:HH:mm:ss} vs {copiedFileInfo.CreationTime:HH:mm:ss}");

                // 4. 清理操作
                Console.WriteLine("\n=== 清理操作 ===");
                if (copiedFileInfo.Exists)
                {
                    copiedFileInfo.Delete();
                    Console.WriteLine($"✓ 已刪除移動後的檔案: {copiedFileInfo.Name}");
                    Console.WriteLine($"刪除後檔案存在: {copiedFileInfo.Exists}"); // 注意：Delete 後 Exists 屬性會更新
                }

                Console.WriteLine("FileInfo 複製與移動操作展示完成！");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有檔案操作權限。");
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine("錯誤：指定的目錄不存在。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"檔案操作發生錯誤: {ex.Message}");
            }
        }
    }

    public static class DirectoryAccess
    {
        /// <summary>
        /// 綜合展示目錄操作：建立、查詢、複製檔案、刪除
        /// </summary>
        public static void Exec()
        {
            Console.WriteLine("【綜合目錄操作展示】");

            string sourceDir = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "source_folder");
            string targetDir = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "target_folder");

            try
            {
                // 1. 建立目錄
                Console.WriteLine("=== 1. 目錄建立 ===");
                Directory.CreateDirectory(sourceDir);
                Directory.CreateDirectory(targetDir);
                Console.WriteLine($"✓ 已建立來源目錄: {sourceDir}");
                Console.WriteLine($"✓ 已建立目標目錄: {targetDir}");

                // 建立子目錄結構
                string subDir1 = Path.Combine(sourceDir, "SubFolder1");
                string subDir2 = Path.Combine(sourceDir, "SubFolder1", "SubFolder1-1");
                Directory.CreateDirectory(subDir2); // CreateDirectory 會自動建立父目錄
                Console.WriteLine($"✓ 已建立多層子目錄: {subDir2}");

                // 2. 建立範例檔案
                Console.WriteLine("\n=== 2. 建立範例檔案 ===");
                CreateSampleFiles(sourceDir);

                // 3. 檢查目錄是否存在
                Console.WriteLine("\n=== 3. 目錄存在檢查 ===");
                bool sourceExists = Directory.Exists(sourceDir);
                bool targetExists = Directory.Exists(targetDir);
                Console.WriteLine($"來源目錄存在: {sourceExists}");
                Console.WriteLine($"目標目錄存在: {targetExists}");

                // 4. 取得目錄中的檔案
                Console.WriteLine("\n=== 4. 目錄檔案列表 ===");
                string[] files = Directory.GetFiles(sourceDir);
                Console.WriteLine($"來源目錄中的檔案數量: {files.Length}");
                foreach (string file in files)
                {
                    string fileName = Path.GetFileName(file);
                    Console.WriteLine($"  📄 {fileName}");
                    FileInfo fileInfo = new FileInfo(file);
                    Console.WriteLine($"  📄 {fileName} ({fileInfo.Length} bytes)");
                }

                // 5. 取得目錄中的子目錄
                Console.WriteLine("\n=== 5. 子目錄列表 ===");
                string[] directories = Directory.GetDirectories(sourceDir);
                Console.WriteLine($"來源目錄中的子目錄數量: {directories.Length}");
                foreach (string dir in directories)
                {
                    string dirName = Path.GetFileName(dir);
                    Console.WriteLine($"  📁 {dirName}");
                }

                // 6. 複製目錄中的所有檔案
                Console.WriteLine("\n=== 6. 檔案複製操作 ===");
                CopyAllFiles(sourceDir, targetDir);


                Console.WriteLine("\n綜合目錄操作展示完成！");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有目錄操作權限。");
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine("錯誤：指定的目錄不存在。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"目錄操作發生錯誤: {ex.Message}");
            }
        }


        /// <summary>
        /// 在指定目錄中建立範例檔案
        /// </summary>
        private static void CreateSampleFiles(string directory)
        {
            string[] fileContents = {
                "這是第一個範例檔案\n建立時間: " + DateTime.Now,
                "這是第二個範例檔案\n用於展示目錄操作",
                "這是第三個範例檔案\n包含一些測試資料\n\n檔案操作展示完成"
            };

            for (int i = 0; i < fileContents.Length; i++)
            {
                string fileName = $"sample_{i + 1}.txt";
                string filePath = Path.Combine(directory, fileName);
                File.WriteAllText(filePath, fileContents[i], Encoding.UTF8);
                Console.WriteLine($"  ✓ 已建立檔案: {fileName}");
            }
        }

        /// <summary>
        /// 複製來源目錄中的所有檔案到目標目錄
        /// </summary>
        private static void CopyAllFiles(string sourceDir, string targetDir)
        {
            string[] files = Directory.GetFiles(sourceDir);
            int copiedCount = 0;

            foreach (string file in files)
            {
                string fileName = Path.GetFileName(file);
                string destPath = Path.Combine(targetDir, fileName);

                try
                {
                    File.Copy(file, destPath, overwrite: true);
                    copiedCount++;
                    Console.WriteLine($"  ✓ 已複製: {fileName}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  ✗ 複製失敗 {fileName}: {ex.Message}");
                }
            }

            Console.WriteLine($"複製統計: 成功 {copiedCount}/{files.Length} 個檔案");
        }


        /// <summary>
        /// 展示目錄移動操作
        /// Directory.Move() 用於重新命名或移動目錄到新位置
        /// </summary>
        public static void Exec2()
        {
            Console.WriteLine("【目錄移動操作展示】");

            string sourceDir = Path.Combine(Directory.GetCurrentDirectory(), "MoveSource");
            string targetDir = Path.Combine(Directory.GetCurrentDirectory(), "MoveTarget");

            try
            {
                // 建立來源目錄和內容
                Console.WriteLine("=== 準備展示環境 ===");
                Directory.CreateDirectory(sourceDir);
                File.WriteAllText(Path.Combine(sourceDir, "test.txt"), "測試檔案內容");
                Directory.CreateDirectory(Path.Combine(sourceDir, "SubDir"));
                File.WriteAllText(Path.Combine(sourceDir, "SubDir", "subtest.txt"), "子目錄檔案");
                Console.WriteLine($"✓ 已建立來源目錄: {sourceDir}");

                // 檢查移動前狀態
                Console.WriteLine("\n=== 移動前狀態檢查 ===");
                Console.WriteLine($"來源目錄存在: {Directory.Exists(sourceDir)}");
                Console.WriteLine($"目標目錄存在: {Directory.Exists(targetDir)}");
                Console.WriteLine($"來源目錄檔案數: {Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories).Length}");

                // 執行目錄移動
                Console.WriteLine("\n=== 執行目錄移動 ===");
                if (!Directory.Exists(sourceDir))
                {
                    Console.WriteLine("來源目錄不存在，無法進行移動操作。");
                    return;
                }

                if (Directory.Exists(targetDir))
                {
                    Console.WriteLine("目標目錄已存在，先刪除...");
                    Directory.Delete(targetDir, recursive: true);
                }


                Directory.Move(sourceDir, targetDir);
                Console.WriteLine($"✓ 目錄已成功移動: {sourceDir} → {targetDir}");

                // 檢查移動後狀態
                Console.WriteLine("\n=== 移動後狀態檢查 ===");
                Console.WriteLine($"來源目錄存在: {Directory.Exists(sourceDir)}");
                Console.WriteLine($"目標目錄存在: {Directory.Exists(targetDir)}");
                if (Directory.Exists(targetDir))
                {
                    Console.WriteLine($"目標目錄檔案數: {Directory.GetFiles(targetDir, "*", SearchOption.AllDirectories).Length}");
                }

                // 清理
                //Console.WriteLine("\n=== 清理 ===");
                //if (Directory.Exists(targetDir))
                //{
                //    Directory.Delete(targetDir, recursive: true);
                //    Console.WriteLine("✓ 已清理目標目錄");
                //}

                Console.WriteLine("目錄移動操作展示完成！");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有移動目錄的權限。");
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine("錯誤：來源目錄不存在。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"目錄移動發生錯誤: {ex.Message}");
            }
        }




    }


    /// <summary>
    /// DirectoryInfo 類別操作展示
    /// DirectoryInfo 提供目錄的詳細資訊和操作方法，採用物件導向設計
    /// 與 Directory 類別不同，DirectoryInfo 適合需要多次操作同一目錄的場景
    /// </summary>
    public static class DirectoryInfoAccess
    {
        /// <summary>
        /// 綜合展示 DirectoryInfo 的各種操作功能
        /// 包含目錄建立、檔案操作、資訊查詢等
        /// </summary>
        public static void Exec()
        {
            Console.WriteLine("【DirectoryInfo 綜合操作展示】");

            string demoPath = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "DirectoryInfoDemo");

            try
            {
                // 1. 建立 DirectoryInfo 物件
                Console.WriteLine("=== 1. DirectoryInfo 物件建立 ===");
                DirectoryInfo dirInfo = new DirectoryInfo(demoPath);
                Console.WriteLine($"目標目錄: {dirInfo.FullName}");
                Console.WriteLine($"目錄名稱: {dirInfo.Name}");
                Console.WriteLine($"父目錄: {dirInfo.Parent?.FullName ?? "無"}");

                // 2. 檢查並建立目錄
                Console.WriteLine("\n=== 2. 目錄建立與檢查 ===");
                if (!dirInfo.Exists)
                {
                    dirInfo.Create();
                    Console.WriteLine("✓ 目錄已建立");
                }
                else
                {
                    Console.WriteLine("目錄已存在");
                }

                // 重新整理以取得最新資訊
                dirInfo.Refresh();
                Console.WriteLine($"目錄存在: {dirInfo.Exists}");
                Console.WriteLine($"建立時間: {dirInfo.CreationTime:yyyy-MM-dd HH:mm:ss}");

                // 3. 建立子目錄結構
                Console.WriteLine("\n=== 3. 子目錄建立 ===");
                DirectoryInfo subDir1 = dirInfo.CreateSubdirectory("Documents");
                DirectoryInfo subDir2 = dirInfo.CreateSubdirectory("Images");
                DirectoryInfo subDir3 = dirInfo.CreateSubdirectory("Data\\Backup"); // 多層子目錄

                Console.WriteLine($"✓ 已建立子目錄: {subDir1.Name}");
                Console.WriteLine($"✓ 已建立子目錄: {subDir2.Name}");
                Console.WriteLine($"✓ 已建立多層子目錄: {subDir3.FullName.Replace(dirInfo.FullName + "\\", "")}");

                // 4. 建立範例檔案
                Console.WriteLine("\n=== 4. 檔案建立 ===");
                CreateSampleFilesInDirectory(dirInfo, subDir1, subDir2, subDir3);

                // 5. 使用 DirectoryInfo 取得檔案資訊
                Console.WriteLine("\n=== 5. 檔案資訊查詢 ===");
                FileInfo[] allFiles = dirInfo.GetFiles("*.*", SearchOption.AllDirectories);
                Console.WriteLine($"總檔案數（包含子目錄）: {allFiles.Length}");

                FileInfo[] rootFiles = dirInfo.GetFiles();
                Console.WriteLine($"根目錄檔案數: {rootFiles.Length}");

                foreach (FileInfo file in rootFiles)
                {
                    Console.WriteLine($"  📄 {file.Name} ({file.Length} bytes, {file.LastWriteTime:MM-dd HH:mm})");
                }

                // 6. 查詢子目錄資訊
                Console.WriteLine("\n=== 6. 子目錄資訊 ===");
                DirectoryInfo[] subDirectories = dirInfo.GetDirectories();
                Console.WriteLine($"直接子目錄數: {subDirectories.Length}");

                foreach (DirectoryInfo subDir in subDirectories)
                {
                    FileInfo[] subFiles = subDir.GetFiles();
                    Console.WriteLine($"  📁 {subDir.Name} (包含 {subFiles.Length} 個檔案)");
                }

                // 7. 搜尋特定類型檔案
                Console.WriteLine("\n=== 7. 特定檔案類型搜尋 ===");
                FileInfo[] txtFiles = dirInfo.GetFiles("*.txt", SearchOption.AllDirectories);
                Console.WriteLine($"所有 TXT 檔案數: {txtFiles.Length}");


                // 8. 展示遞迴目錄複製
                Console.WriteLine("\n=== 8. 遞迴目錄複製展示 ===");
                string backupPath = Path.Combine(Directory.GetCurrentDirectory(), "Resource", "DirectoryBackup");
                DirectoryInfo backupDir = new DirectoryInfo(backupPath);

                if (backupDir.Exists)
                {
                    backupDir.Delete(recursive: true);
                }

                CopyAllRecursive(dirInfo, backupDir);
                Console.WriteLine($"✓ 已遞迴複製到: {backupDir.FullName}");

                return;
                // 清理
                Console.WriteLine("\n=== 清理 ===");
                dirInfo.Delete(recursive: true);
                backupDir.Delete(recursive: true);
                Console.WriteLine("✓ 已清理所有展示目錄");

                Console.WriteLine("\nDirectoryInfo 綜合操作展示完成！");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("錯誤：沒有目錄操作權限。");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"目錄操作發生錯誤: {ex.Message}");
            }
        }

        /// <summary>
        /// 在指定目錄中建立範例檔案
        /// </summary>
        private static void CreateSampleFilesInDirectory(DirectoryInfo rootDir, DirectoryInfo docsDir, DirectoryInfo imagesDir, DirectoryInfo dataDir)
        {
            // 在根目錄建立檔案
            File.WriteAllText(Path.Combine(rootDir.FullName, "readme.txt"), "專案說明檔案\n建立時間: " + DateTime.Now);
            File.WriteAllText(Path.Combine(rootDir.FullName, "config.json"), "{ \"version\": \"1.0\", \"debug\": true }");

            // 在 Documents 目錄建立檔案
            File.WriteAllText(Path.Combine(docsDir.FullName, "manual.txt"), "使用手冊內容");
            File.WriteAllText(Path.Combine(docsDir.FullName, "notes.md"), "# 專案筆記\n\n這是 Markdown 格式的筆記。");

            // 在 Images 目錄建立假的圖片檔案（實際為文字）
            File.WriteAllText(Path.Combine(imagesDir.FullName, "logo.png"), "這是假的PNG檔案內容");
            File.WriteAllText(Path.Combine(imagesDir.FullName, "banner.jpg"), "這是假的JPG檔案內容");

            // 在 Data\\Backup 目錄建立檔案
            File.WriteAllText(Path.Combine(dataDir.FullName, "backup.sql"), "-- SQL 備份檔案\nSELECT * FROM users;");

            Console.WriteLine("✓ 已在各目錄建立範例檔案");
        }

        /// <summary>
        /// 遞迴複製目錄及其所有內容
        /// 展示 DirectoryInfo 的進階應用
        /// </summary>
        /// <param name="source">來源目錄</param>
        /// <param name="target">目標目錄</param>
        private static void CopyAllRecursive(DirectoryInfo source, DirectoryInfo target)
        {
            try
            {
                // 如果來源和目標相同，不執行複製
                if (string.Equals(source.FullName, target.FullName, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("來源和目標目錄相同，跳過複製操作");
                    return;
                }

                // 建立目標目錄
                if (!target.Exists)
                {
                    target.Create();
                }

                // 複製所有檔案
                FileInfo[] files = source.GetFiles();
                foreach (FileInfo file in files)
                {
                    string targetFilePath = Path.Combine(target.FullName, file.Name);
                    file.CopyTo(targetFilePath, overwrite: true);
                }

                // 遞迴複製所有子目錄
                DirectoryInfo[] subDirectories = source.GetDirectories();
                foreach (DirectoryInfo subDir in subDirectories)
                {
                    DirectoryInfo targetSubDir = target.CreateSubdirectory(subDir.Name);
                    CopyAllRecursive(subDir, targetSubDir);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"複製目錄時發生錯誤: {ex.Message}");
            }
        }
    }
}
