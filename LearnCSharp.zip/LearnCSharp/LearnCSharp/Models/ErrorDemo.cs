﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    public class ErrorDemo1
    {
        public void Method()
        {
            var e2 = new ErrorDemo2();
            e2.Method();
        }
    }

    public class ErrorDemo2
    {
        public void Method()
        {
            try
            {
                var e3 = new ErrorDemo3();
                e3.Method();
            }
            catch (Exception ex)
            {
                //....
                //throw;
                throw ex; // 重拋例外, 這樣會讓堆疊資訊不見
            }
            //var e3 = new ErrorDemo3();
            //e3.Method();
        }
    }

    public class ErrorDemo3
    {
        public void Method()
        {
            var i = 1;
            var j = 0;
            var k = i / j; // 這裡會引發除以零的錯誤
            //try
            //{
            //    var i = 1;
            //    var j = 0;
            //    var k = i / j; // 這裡會引發除以零的錯誤
            //}
            //catch (Exception ex)
            //{
            //    //.....
            //    //throw;
            //    //throw ex;
            //}
        }
    }
}
