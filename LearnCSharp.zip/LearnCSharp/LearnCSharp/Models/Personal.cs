﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    internal class Personal
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public double Height { get; set; }
        public double Weight { get; set; }
        public Personal(string name, double height, double weight)
        {
            Id = Guid.NewGuid();
            Name = name;
            Height = height;
            Weight = weight;
        }
    }

    internal class BmiCalculator
    {
        public double CalculateBMI(Personal person)
        {
            if (person.Height <= 0 || person.Weight <= 0)
            {
                throw new ArgumentException("Height and Weight must be greater than zero.");
            }
            person.Weight = person.Weight * 1.5;
            return person.Weight / (person.Height * person.Height);
        }

        public double CalculateBMI(double height, double weight)
        {
            if (height <= 0 || weight <= 0)
            {
                throw new ArgumentException("Height and Weight must be greater than zero.");
            }
            weight = weight * 1.5; // 假設這是某種計算邏輯
            return weight / (height * height);
        }

        //public double CalculateBMI(ref double height, ref double weight)
        //{
        //    if (height <= 0 || weight <= 0)
        //    {
        //        throw new ArgumentException("Height and Weight must be greater than zero.");
        //    }
        //    weight = weight * 1.5; // 假設這是某種計算邏輯
        //    return weight / (height * height);
        //}


        //可選擇性參數的版本
        public double CalculateBMI(double height, double weight, bool isShowBmiStatus = false)
        {
            if (height <= 0 || weight <= 0)
            {
                throw new ArgumentException("Height and Weight must be greater than zero.");
            }

            if (isShowBmiStatus)
            {
                if (weight < 18.5 * height * height)
                {
                    Console.WriteLine("體重過輕");
                }
                else if (weight < 24 * height * height)
                {
                    Console.WriteLine("體重正常");
                }
                else if (weight < 27 * height * height)
                {
                    Console.WriteLine("體重過重");
                }
                else
                {
                    Console.WriteLine("肥胖");
                }
            }


            return weight / (height * height);
        }

        public double CalculateBMI(double height, double weight, out string bmiStatus)
        {
            if (height <= 0 || weight <= 0)
            {
                throw new ArgumentException("Height and Weight must be greater than zero.");
            }

            if (weight < 18.5 * height * height)
            {
                bmiStatus = "體重過輕";
            }
            else if (weight < 24 * height * height)
            {
                bmiStatus = "體重正常";
            }
            else if (weight < 27 * height * height)
            {
                bmiStatus = "體重過重";
            }
            else
            {
                bmiStatus = "肥胖";
            }

            return weight / (height * height);
        }

    }
}
