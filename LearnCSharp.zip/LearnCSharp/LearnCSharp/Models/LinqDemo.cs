﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// LINQ (Language Integrated Query) 教學展示類別
    /// 
    /// LINQ 是 C# 中整合的查詢語言，提供統一的查詢語法來操作各種資料來源
    /// 包括陣列、集合、資料庫、XML 等。
    /// 
    /// LINQ 的三個基本步驟：
    /// 1. 資料來源 (Data Source)
    /// 2. 查詢建立 (Query Creation)
    /// 3. 查詢執行 (Query Execution)
    /// 
    /// LINQ 提供兩種語法：
    /// - 查詢語法 (Query Syntax): from x in data where x.Property > value select x
    /// - 方法語法 (Method Syntax): data.Where(x => x.Property > value).Select(x => x)
    /// </summary>
    public static class LinqDemo
    {
        /// <summary>
        /// 範例 1: 基本 LINQ 查詢 - 篩選偶數
        /// 展示 LINQ (Query Syntax) 的基本結構和查詢語法
        /// </summary>
        static public void Run1()
        {
            Console.WriteLine("=== 範例 1: 基本 LINQ 查詢 - 篩選偶數 ===");

            // 1. 資料來源 (Data Source)
            // 建立一個包含 0 到 6 的整數陣列
            int[] numbers = new int[7] { 0, 1, 2, 3, 4, 5, 6 };
            Console.WriteLine($"原始資料: [{string.Join(", ", numbers)}]");

            // 2. LINQ 查詢建立 (Query Creation)
            // 使用查詢語法篩選出偶數
            // 注意：查詢在此階段不會執行，只是建立查詢物件
            var numQuery =
                from num in numbers
                where (num % 2) == 0  // 篩選條件：數字除以 2 的餘數為 0（偶數）
                select num;           // 選擇符合條件的數字

            // 3. 查詢執行 (Query Execution)
            // 當我們遍歷查詢結果時，查詢才會真正執行（延遲執行）
            Console.WriteLine("篩選出的偶數:");
            foreach (int item in numQuery)
            {
                Console.WriteLine($"  {item}");
            }

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 2: 物件集合查詢 - 基本篩選
        /// 展示 (Query Syntax)如何查詢物件集合，根據物件屬性進行篩選
        /// </summary>
        static public void Run2()
        {
            Console.WriteLine("=== 範例 2: 物件集合查詢 - 基本篩選 ===");

            // 1. 資料來源 (Data Source)
            // 建立課程資料集合
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 30 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };
            Console.WriteLine("所有課程資料已建立");

            // 2. LINQ 查詢建立 (Query Creation)
            // 篩選出特定老師的課程
            var coursedata =
                from courseitem in courses
                where courseitem.Teacher == "陳葵懋"  // 篩選條件：授課老師為「陳葵懋」
                select courseitem;                    // 選擇整個課程物件

            // 3. LINQ 查詢執行 (Query Execution)
            Console.WriteLine("陳葵懋老師的課程:");
            foreach (CourseData item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 課程時數: {item.Hours} 小時");
            }

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 2.1: 匿名類型投影查詢 (Anonymous Type Projection)
        /// 展示(Query Syntax)如何使用 Tuple 來選擇特定欄位，而不是整個物件
        /// </summary>
        static public void Run21()
        {
            Console.WriteLine("=== 範例 2.1: 匿名類型投影查詢 (Tuple) ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 30 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 2. LINQ 查詢建立 (Query Creation)
            // 使用 Tuple 投影，只選擇需要的欄位
            var coursedata =
                from courseitem in courses
                where courseitem.Teacher == "陳葵懋"
                select (courseitem.Name, courseitem.Teacher);  // 使用 Tuple 語法選擇特定欄位

            // 3. LINQ 查詢執行 (Query Execution)
            Console.WriteLine("陳葵懋老師的課程 (使用 Tuple 投影):");
            foreach (var item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 授課老師: {item.Teacher}");
            }

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 2.2: 具名類型投影查詢 (Named Type Projection)
        /// 展示(Query Syntax)如何將查詢結果投影到自定義的類別
        /// </summary>
        static public void Run22()
        {
            Console.WriteLine("=== 範例 2.2: 具名類型投影查詢 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 30 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 2. LINQ 查詢建立 (Query Creation)
            // 將查詢結果投影到 CourseDataLite 類別
            var coursedata =
                from courseitem in courses
                where courseitem.Teacher == "陳葵懋"
                select new CourseDataLite
                {
                    Name = courseitem.Name,
                    Teacher = courseitem.Teacher
                };

            // 3. LINQ 查詢執行 (Query Execution)
            Console.WriteLine("陳葵懋老師的課程 (使用具名類型投影):");
            foreach (var item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 授課老師: {item.Teacher}");
            }

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 3: 立即執行查詢 (Immediate Execution)
        /// 展示(Query Syntax)如何使用 ToList() 來強制立即執行查詢並快取結果
        /// </summary>
        static public void Run3()
        {
            Console.WriteLine("=== 範例 3: 立即執行查詢 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 30 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 2. LINQ 查詢建立並立即執行 (Query Creation with Immediate Execution)
            // 使用 ToList() 立即強制執行任何查詢，並快取其結果
            // 這與延遲執行 (Deferred Execution) 不同
            var coursedata =
                (from courseitem in courses
                 where courseitem.Teacher == "陳葵懋"
                 select courseitem).ToList();  // ToList() 強制立即執行查詢

            Console.WriteLine($"查詢結果已快取，共找到 {coursedata.Count} 筆資料");

            // 3. 使用已快取的結果 (Using Cached Results)
            Console.WriteLine("陳葵懋老師的課程 (立即執行結果):");
            foreach (CourseData item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 課程時數: {item.Hours} 小時");
            }

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 4: 排序查詢 (Ordering)
        /// 展示(Query Syntax)如何使用 orderby 子句對查詢結果進行排序
        /// </summary>
        static public void Run4()
        {
            Console.WriteLine("=== 範例 4: 排序查詢 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },  // 修改時數以展示排序效果
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 2. LINQ 查詢建立 (Query Creation)
            // 使用 orderby 進行多欄位排序
            var coursedata =
                (from courseitem in courses
                 where courseitem.Teacher == "陳葵懋"
                 orderby courseitem.Hours, courseitem.Name  // 先按時數排序，再按課程名稱排序
                 select courseitem).ToList();

            Console.WriteLine("陳葵懋老師的課程 (按時數和課程名稱排序):");
            foreach (CourseData item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 課程時數: {item.Hours} 小時");
            }

            Console.WriteLine("\n--- 降序排列範例 ---");

            // 降序排列範例
            var coursedataDesc =
                (from courseitem in courses
                 where courseitem.Teacher == "陳葵懋"
                 orderby courseitem.Hours descending, courseitem.Name descending
                 select courseitem).ToList();

            Console.WriteLine("陳葵懋老師的課程 (按時數和課程名稱降序排序):");
            foreach (CourseData item in coursedataDesc)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 課程時數: {item.Hours} 小時");
            }

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 5: 字串包含查詢 (String Contains Query)
        /// 展示(Query Syntax)如何使用 Contains() 方法進行模糊搜尋，類似 SQL 的 LIKE 操作
        /// </summary>
        static public void Run5()
        {
            Console.WriteLine("=== 範例 5: 字串包含查詢 (查詢語法) ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 2. LINQ 查詢建立 (Query Creation)
            // 使用 Contains() 方法搜尋課程名稱包含特定字串的課程
            var coursedata =
                from courseitem in courses
                where courseitem.Name.Contains("Python")   // 篩選課程名稱包含 "Python" 的課程
                orderby courseitem.Hours                  // 按課程時數排序
                select courseitem;

            // 3. LINQ 查詢執行 (Query Execution)
            Console.WriteLine("包含 'Python' 的課程 (按時數排序):");
            foreach (CourseData item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}");
                Console.WriteLine($"  授課老師: {item.Teacher}");
                Console.WriteLine($"  課程時數: {item.Hours} 小時");
                Console.WriteLine($"  課程類別: {item.Category}");
                Console.WriteLine("  ---");
            }

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 5.1: 方法語法查詢 (Method Syntax Query)
        /// 展示與範例 5 相同功能，但使用方法語法而非查詢語法
        /// 比較兩種 LINQ 語法的差異
        /// </summary>
        static public void Run51()
        {
            Console.WriteLine("=== 範例 5.1: 字串包含查詢 (Method Syntax) ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 2. LINQ 查詢建立 (Query Creation - Method Syntax)
            // 使用方法語法 (Method Syntax) 實現與 Run5() 相同的查詢
            // 方法語法使用 Lambda 表達式和擴展方法
            var coursedata = courses
                .Where(c => c.Name.Contains("Python"))  // 篩選包含 "Python" 的課程
                .OrderBy(c => c.Hours)                  // 按時數排序
                .Select(c => c);                        // 選擇整個物件

            // 簡化寫法（省略不必要的 Select）
            // var coursedata = courses.Where(c => c.Name.Contains("Python")).OrderBy(c => c.Hours);

            // 3. LINQ 查詢執行 (Query Execution)
            Console.WriteLine("包含 'Python' 的課程 (使用方法語法):");
            foreach (CourseData item in coursedata)
            {
                Console.WriteLine($"  課程名稱: {item.Name}, 課程時數: {item.Hours} 小時");
            }

            Console.WriteLine("\n--- 語法比較說明 ---");
            Console.WriteLine("查詢語法: from c in courses where c.Name.Contains(\"Python\") orderby c.Hours select c");
            Console.WriteLine("方法語法: courses.Where(c => c.Name.Contains(\"Python\")).OrderBy(c => c.Hours)");

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 6: 複合查詢條件
        /// 展示(Query Syntax)如何使用多個查詢條件
        /// </summary>
        public static void Run6()
        {
            Console.WriteLine("=== 範例 6: 複合查詢條件 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 查詢程式設計類別且時數大於等於 20 小時的課程
            var coursedata =
                from course in courses
                where course.Category == "PG" && course.Hours >= 20
                orderby course.Hours descending
                select course;

            Console.WriteLine("程式設計類別且時數 >= 20 小時的課程:");
            foreach (var item in coursedata)
            {
                Console.WriteLine($"  {item.Name} - {item.Hours} 小時 ({item.Teacher})");
            }

            Console.WriteLine();
        }

        /// <summary>
        /// 範例 7: 分組查詢 (Grouping)
        /// 展示如何使用 group by 進行資料分組
        /// </summary>
        public static void Run7()
        {
            Console.WriteLine("=== 範例 7: 分組查詢 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 按授課老師分組
            var groupedCourses =
                from course in courses
                group course by course.Teacher into teacherGroup
                select new
                {
                    Teacher = teacherGroup.Key,
                    Courses = teacherGroup.ToList(),
                    TotalHours = teacherGroup.Sum(c => c.Hours)
                };

            Console.WriteLine("按授課老師分組的課程:");
            foreach (var group in groupedCourses)
            {
                Console.WriteLine($"\n老師: {group.Teacher} (總時數: {group.TotalHours} 小時)");
                foreach (var course in group.Courses)
                {
                    Console.WriteLine($"  - {course.Name} ({course.Hours} 小時)");
                }
            }

            Console.WriteLine();
        }


        /// <summary>
        /// 範例 8: 統計查詢 (Aggregation)
        /// 展示(Method Syntax)常用的統計函式：Count, Sum, Average, Max, Min
        /// </summary>
        public static void Run8()
        {
            Console.WriteLine("=== 範例 8: 統計查詢 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };

            // 各種統計查詢
            int totalCourses = courses.Count();
            int totalHours = courses.Sum(c => c.Hours);
            double averageHours = courses.Average(c => c.Hours);
            int maxHours = courses.Max(c => c.Hours);
            int minHours = courses.Min(c => c.Hours);

            Console.WriteLine($"課程統計資訊:");
            Console.WriteLine($"  總課程數: {totalCourses} 門");
            Console.WriteLine($"  總時數: {totalHours} 小時");
            Console.WriteLine($"  平均時數: {averageHours:F2} 小時");
            Console.WriteLine($"  最長課程: {maxHours} 小時");
            Console.WriteLine($"  最短課程: {minHours} 小時");

            // 條件統計
            int pgCourses = courses.Count(c => c.Category == "PG");
            Console.WriteLine($"  程式設計類課程: {pgCourses} 門");

            Console.WriteLine();
        }

        /// <summary>
        /// 範例 : 基本內部聯接 (Inner Join)
        /// 展示如何聯接兩個集合，只顯示兩邊都存在的資料
        /// 類似 SQL 的 INNER JOIN
        /// </summary>
        public static void Exe9()
        {
            Console.WriteLine("=== 範例 : 基本內部聯接 (Inner Join) ===");

            // 員工資料
            List<Emp> emps = new List<Emp>
            {
                new Emp { EmployeeId = "001", Name = "Ian" },
                new Emp { EmployeeId = "002", Name = "Cindy" },
                new Emp { EmployeeId = "003", Name = "Andy" },
                new Emp { EmployeeId = "004", Name = "Allen" }    // 注意：此員工沒有訂單
            };

            Console.WriteLine("員工資料:");
            foreach (var emp in emps)
            {
                Console.WriteLine($"  {emp.EmployeeId} - {emp.Name}");
            }

            // 訂單資料
            List<OrderData> orders = new List<OrderData>
            {
                new OrderData { EmployeeId = "001", Amount = 50000 },
                new OrderData { EmployeeId = "002", Amount = 43000 },
                new OrderData { EmployeeId = "003", Amount = 970000 },
                new OrderData { EmployeeId = "003", Amount = 480000 },
                new OrderData { EmployeeId = "001", Amount = 950000 },
                new OrderData { EmployeeId = "001", Amount = 57000 }
                // 注意：員工 004 沒有任何訂單
            };
            Console.WriteLine("\n訂單資料:");
            foreach (var order in orders)
            {
                Console.WriteLine($"  員工ID: {order.EmployeeId}, 金額: {order.Amount:C}");
            }

            // LINQ 內部聯接查詢
            // join 關鍵字用於聯接兩個資料來源
            // on...equals 用於指定聯接條件
            var query =
                from o in orders
                join e in emps on o.EmployeeId equals e.EmployeeId  // 根據員工ID聯接
                select new { e.EmployeeId, e.Name, o.Amount };      // 選擇需要的欄位

            Console.WriteLine("\n聯接結果 (只顯示有訂單的員工):");
            foreach (var item in query)
            {
                Console.WriteLine($"  員工ID: {item.EmployeeId}, 姓名: {item.Name}, 訂單金額: {item.Amount:C}");
            }

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 : 左外部聯接 (Left Outer Join)
        /// 展示如何實現 SQL 中的 LEFT JOIN 功能
        /// 即使員工沒有訂單，也會顯示在結果中
        /// </summary>
        public static void Exe10()
        {
            Console.WriteLine("=== 範例 : 左外部聯接 (Left Outer Join) ===");
           
            // 員工資料
            List<Emp> emps = new List<Emp>
            {
                new Emp { EmployeeId = "001", Name = "Ian" },
                new Emp { EmployeeId = "002", Name = "Cindy" },
                new Emp { EmployeeId = "003", Name = "Andy" },
                new Emp { EmployeeId = "004", Name = "Allen" }    // 注意：此員工沒有訂單
            };

            Console.WriteLine("員工資料:");
            foreach (var emp in emps)
            {
                Console.WriteLine($"  {emp.EmployeeId} - {emp.Name}");
            }


            Console.WriteLine("注意：員工 004 (Allen) 沒有任何訂單");

            // 訂單資料
            List<OrderData> orders = new List<OrderData>
            {
                new OrderData { EmployeeId = "001", Amount = 50000 },
                new OrderData { EmployeeId = "002", Amount = 43000 },
                new OrderData { EmployeeId = "003", Amount = 970000 },
                new OrderData { EmployeeId = "003", Amount = 480000 },
                new OrderData { EmployeeId = "001", Amount = 950000 },
                new OrderData { EmployeeId = "001", Amount = 57000 }
                // 注意：員工 004 沒有任何訂單
            };
            Console.WriteLine("\n訂單資料:");
            foreach (var order in orders)
            {
                Console.WriteLine($"  員工ID: {order.EmployeeId}, 金額: {order.Amount:C}");
            }


            /*
             * 左外部聯接的實現步驟：
             * 1. 對於每個 emps 中的員工 e，在 orders 中尋找匹配的訂單
             * 2. 使用 into joinResult 將該員工的所有匹配訂單放入 joinResult 集合
             *    - 有訂單的員工：joinResult 包含該員工的所有訂單
             *    - 沒有訂單的員工：joinResult 是空集合（但仍然存在）
             * 3. from subOrder in joinResult.DefaultIfEmpty() 處理兩種情況：
             *    - joinResult 有內容：正常遍歷每個訂單
             *    - joinResult 是空的：返回單一 null 值，確保員工仍出現在結果中
             */
            var query =
                from e in emps
                join o in orders on e.EmployeeId equals o.EmployeeId into joinResult  // 為每個員工建立其對應的訂單集合
                from subOrder in joinResult.DefaultIfEmpty()                          // 處理空集合情況，確保左聯接效果
                select new
                {
                    e.EmployeeId,
                    e.Name,
                    Amount = subOrder != null ? subOrder.Amount : 0 // 若無對應的訂單則顯示金額為0
                };

            Console.WriteLine("左外部聯接結果 (所有員工都會顯示):");
            foreach (var item in query)
            {
                string amountText = item.Amount == 0 ? "無訂單" : item.Amount.ToString("C");
                Console.WriteLine($"  員工ID: {item.EmployeeId}, 姓名: {item.Name}, 訂單金額: {amountText}");
            }

            Console.WriteLine(); // 空行分隔
        }
    }


    /// <summary>
    /// LINQ 方法語法教學範例 (Method Syntax Tutorial)
    /// 
    /// 本類別專門展示 LINQ 的方法語法 (Method Syntax)，
    /// 相對於查詢語法 (Query Syntax)，方法語法更接近傳統的程式設計風格
    /// 
    /// 學習目標：
    /// - 理解 Lambda 表達式的核心概念與語法
    /// - 掌握常用 LINQ 方法的使用技巧
    /// - 學會方法鏈結 (Method Chaining) 的組合技巧
    /// - 建構複雜查詢的方法語法實現
    /// - 比較方法語法與查詢語法的差異與優勢
    /// </summary>
    public static class MethodQueryLab
    {
        /// <summary>
        /// 初始化課程資料的輔助方法
        /// </summary>
        /// <returns>課程資料清單</returns>
        private static List<CourseData> InitializeCourseData()
        {
            return new List<CourseData>
            {
                new CourseData { Category = "DB", Name = "SQL Server資料庫概論", Teacher = "蘇紘賢", Hours = 15 },
                new CourseData { Category = "AI", Name = "Python資料科學應用開發", Teacher = "楊志強", Hours = 66 },
                new CourseData { Category = "AI", Name = "Python與AI人工智慧開發入門", Teacher = "楊志強", Hours = 30 },
                new CourseData { Category = "PG", Name = "C語言程式設計", Teacher = "梁少吉", Hours = 18 },
                new CourseData { Category = "PG", Name = "Java 基礎程式設計", Teacher = "許裕永", Hours = 15 },
                new CourseData { Category = "PG", Name = "C#程式設計", Teacher = "陳葵懋", Hours = 60 },
                new CourseData { Category = "PG", Name = "ASP.NET 程式設計", Teacher = "陳葵懋", Hours = 30 }
            };
        }


        /// <summary>
        /// 初始化員工資料
        /// </summary>
        /// <returns>員工清單</returns>
        private static List<Emp> InitializeEmployees()
        {
            return new List<Emp>
            {
                new Emp { EmployeeId = "001", Name = "Ian" },
                new Emp { EmployeeId = "002", Name = "Cindy" },
                new Emp { EmployeeId = "003", Name = "Andy" },
                new Emp { EmployeeId = "004", Name = "Allen" }    // 注意：此員工沒有訂單
            };
        }

        /// <summary>
        /// 初始化訂單資料
        /// </summary>
        /// <returns>訂單清單</returns>
        private static List<OrderData> InitializeOrderData()
        {
            return new List<OrderData>
            {
                new OrderData { EmployeeId = "001", Amount = 50000 },
                new OrderData { EmployeeId = "002", Amount = 43000 },
                new OrderData { EmployeeId = "003", Amount = 970000 },
                new OrderData { EmployeeId = "003", Amount = 480000 },
                new OrderData { EmployeeId = "001", Amount = 950000 },
                new OrderData { EmployeeId = "001", Amount = 57000 }
                // 注意：員工 004 沒有任何訂單
            };
        }

        /// <summary>
        /// 初始化員工銷售資料
        /// </summary>
        /// <returns>員工銷售清單</returns>
        private static List<EmpSales> InitializeEmpSalesData()
        {
            return new List<EmpSales>
            {
                new EmpSales { EmployeeId = "001", Name = "Ian", Amount = 50000 },
                new EmpSales { EmployeeId = "002", Name = "Andy", Amount = 43000 },
                new EmpSales { EmployeeId = "003", Name = "Emma", Amount = 970000 },
                new EmpSales { EmployeeId = "003", Name = "Emma", Amount = 480000 },
                new EmpSales { EmployeeId = "001", Name = "Ian", Amount = 950000 },
                new EmpSales { EmployeeId = "001", Name = "Ian", Amount = 57000 }
            };
        }

        /// <summary>
        /// 範例 1: Lambda 表達式基礎
        /// 展示 Lambda 表達式的基本語法和 FindAll 方法的使用
        /// Lambda 表達式格式: (參數) => 表達式
        /// </summary>
        public static void Exec1()
        {
            Console.WriteLine("=== 範例 1: Lambda 表達式基礎 ===");

            // Lambda 表達式是 C# 中的一種語法糖，允許你定義匿名函式（即沒有名稱的函式）
            // Lambda 表達式使用 => 符號來分隔參數列表和表達式主體
            // 格式: (參數) => 表達式 或 (參數) => { 程式碼區塊 }

            // 1. 資料來源 (Data Source)
            int[] numbers = new int[7] { 0, 1, 2, 3, 4, 5, 6 };
            Console.WriteLine($"原始資料: [{string.Join(", ", numbers)}]");

            // 2. 查詢建立 (Query Creation) - 使用 List.FindAll 方法
            // x => x % 2 == 0 是一個 Lambda 表達式
            // x 是參數，x % 2 == 0 是條件表達式
            //var query = numbers.ToList().FindAll(x => x % 2 == 0);

            //多個條件篩選, 篩選出大於0的偶數
            var query = numbers.ToList().FindAll(x => x % 2 == 0 && x > 0);

            Console.WriteLine("使用 FindAll 方法篩選偶數:");
            Console.WriteLine("Lambda 表達式: x => x % 2 == 0");
            Console.WriteLine("意思是: 對於每個 x，如果 x 除以 2 的餘數等於 0，則選取此項目");

            // 3. 查詢執行 (Query Execution)
            Console.WriteLine("\n篩選結果:");
            foreach (int item in query)
            {
                Console.WriteLine($"  {item}");
            }

            // 比較：使用 LINQ Where 方法的相同功能
            var linqQuery = numbers.Where(x => x % 2 == 0);
            Console.WriteLine("\n使用 LINQ Where 方法的相同結果:");
            foreach (int item in linqQuery)
            {
                Console.WriteLine($"  {item}");
            }

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 2: 常用 LINQ 方法查詢綜合示範
        /// 展示各種常用的 LINQ 方法：FirstOrDefault, FindAll, Where, Select, OrderBy 等
        /// 比較 List 方法與 LINQ 方法的差異
        /// </summary>
        public static void Exec2()
        {
            Console.WriteLine("=== 範例 2: 常用 LINQ 方法查詢 ===");

            // 1. 資料來源 (Data Source)
            List<CourseData> courses = InitializeCourseData();

            Console.WriteLine("課程資料已初始化，開始示範各種查詢方法...\n");

            // === 示範 1: FirstOrDefault - 取得第一筆符合條件的資料 ===
            Console.WriteLine("--- 示範 1: FirstOrDefault (取得第一筆程式設計課程) ---");
            // List<T> 沒有 FirstOrDefault 方法，這是 LINQ 的擴展方法
            // 當找不到符合條件的資料時，FirstOrDefault 會回傳預設值 (null for reference types)
            var query0 = courses.FirstOrDefault(c => c.Category == "PG");
            if (query0 != null)
            {
                Console.WriteLine($"第一筆程式設計課程: {query0.Name} (老師: {query0.Teacher})");
            }
            else
            {
                Console.WriteLine("找不到程式設計課程");
            }

            // === 示範 2: FindAll vs Where - 比較 List 方法與 LINQ 方法 ===
            Console.WriteLine("\n--- 示範 2: FindAll vs Where (篩選程式設計課程) ---");

            // List.FindAll 方法 (List<T> 專用)
            // 沒有資料時回傳空集合，而非 null
            var query1 = courses.FindAll(course => course.Category == "PG");
            Console.WriteLine("使用 List.FindAll 方法:");
            foreach (var item in query1)
            {
                Console.WriteLine($"  課程: {item.Name}, 類別: {item.Category}");
            }

            // LINQ Where 方法 (IEnumerable<T> 通用)
            // 沒有資料時也回傳空集合, 而非 null
            // 任何實作 IEnumerable<T> 的集合都可以使用 Where 方法,例如陣列、List、Dictionary 等
            Console.WriteLine("\nLINQ Where 方法 (功能相同，但更通用):");
            var linqWhere = courses.Where(course => course.Category == "PG");
            foreach (var item in linqWhere)
            {
                Console.WriteLine($"  課程: {item.Name}, 類別: {item.Category}");
            }

            // === 示範 3: 複合條件篩選 ===
            Console.WriteLine("\n--- 示範 3: 複合條件篩選 (程式設計 + 特定老師) ---");

            var query2 = courses.FindAll(course => course.Category == "PG" && course.Teacher == "陳葵懋");
            Console.WriteLine("使用 FindAll - 程式設計類且老師是陳葵懋:");
            foreach (var item in query2)
            {
                Console.WriteLine($"  課程: {item.Name}, 類別: {item.Category}, 老師: {item.Teacher}");
            }

            var query3 = courses.Where(course => course.Category == "PG" && course.Teacher == "陳葵懋");
            Console.WriteLine("\n使用 Where - 相同條件:");
            foreach (var item in query3)
            {
                Console.WriteLine($"  課程: {item.Name}, 類別: {item.Category}, 老師: {item.Teacher}");
            }

            // === 示範 4: Select 投影 - 只選擇特定欄位 ===
            Console.WriteLine("\n--- 示範 4: Select 投影 (只取課程名稱) ---");
            var query4 = courses.Select(course => course.Name);
            Console.WriteLine("所有課程名稱:");
            foreach (var name in query4)
            {
                Console.WriteLine($"  課程名稱: {name}");
            }

            // === 示範 5: Select 匿名類型投影 ===
            Console.WriteLine("\n--- 示範 5: Select 匿名類型投影 (課程名稱 + 老師) ---");
            // 使用匿名類型來投影多個欄位
            // 匿名類型語法: new { 欄位1, 欄位2, ... }
            var query5 = courses.Select(course => new { course.Name, course.Teacher });
            Console.WriteLine("課程名稱與授課老師:");
            foreach (var item in query5)
            {
                Console.WriteLine($"  課程: {item.Name}, 老師: {item.Teacher}");
            }

            // === 示範 6: Select 具名類型投影 ===
            Console.WriteLine("\n--- 示範 6: Select 具名類型投影 (CourseDataLite) ---");
            var query51 = courses.Select(course => new CourseDataLite()
            {
                Name = course.Name,
                Teacher = course.Teacher
            });
            Console.WriteLine("使用 CourseDataLite 類型:");
            foreach (var item in query51)
            {
                Console.WriteLine($"  課程: {item.Name}, 老師: {item.Teacher}");
            }

            // === 示範 7: 方法鏈結 (Method Chaining) - Where + Select ===
            Console.WriteLine("\n--- 示範 7: 方法鏈結 Where + Select (匿名類型) ---");
            var query6 = courses
                .Where(course => course.Category == "PG" && course.Teacher == "陳葵懋")
                .Select(course => new { course.Name, course.Teacher });
            Console.WriteLine("程式設計課程 (陳葵懋老師) - 匿名類型:");
            foreach (var item in query6)
            {
                Console.WriteLine($"  課程: {item.Name}, 老師: {item.Teacher}");
            }

            // === 示範 8: 方法鏈結 - Where + Select (具名類型) ===
            Console.WriteLine("\n--- 示範 8: 方法鏈結 Where + Select (具名類型) ---");
            var query61 = courses
                .Where(course => course.Category == "PG" && course.Teacher == "陳葵懋")
                .Select(course => new CourseDataLite()
                {
                    Name = course.Name,
                    Teacher = course.Teacher
                });
            Console.WriteLine("程式設計課程 (陳葵懋老師) - CourseDataLite:");
            foreach (var item in query61)
            {
                Console.WriteLine($"  課程: {item.Name}, 老師: {item.Teacher}");
            }

            // === 示範 9: 複雜方法鏈結 - Where + OrderBy + OrderByDescending + Select ===
            Console.WriteLine("\n--- 示範 9: 複雜方法鏈結 (篩選 + 多層排序 + 投影) ---");
            var query62 = courses
                .Where(course => course.Category == "PG" && course.Teacher == "陳葵懋")
                .OrderBy(course => course.Name)           // 先按課程名稱升序排序
                .ThenByDescending(course => course.Hours) // 再按時數降序排序
                .Select(course => new { course.Name, course.Teacher, course.Hours });

            Console.WriteLine("程式設計課程 (按名稱升序，時數降序):");
            foreach (var item in query62)
            {
                Console.WriteLine($"  課程: {item.Name}, 老師: {item.Teacher}, 時數: {item.Hours}");
            }

            Console.WriteLine("\n方法鏈結說明:");
            Console.WriteLine("courses.Where(...).OrderBy(...).ThenByDescending(...).Select(...)");
            Console.WriteLine("每個方法都返回 IEnumerable，可以繼續串接其他 LINQ 方法");

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 3: 單一資料集分組查詢 (Group By - Single Key)
        /// 展示如何使用 GroupBy 方法按單一鍵值進行分組統計
        /// </summary>
        public static void Exec3()
        {
            Console.WriteLine("=== 範例 3: 單一資料集分組查詢 ===");

            // 訂單資料 - 員工的銷售記錄
            List<OrderData> orders = InitializeOrderData();

            Console.WriteLine("原始訂單資料:");
            foreach (var order in orders)
            {
                Console.WriteLine($"  員工ID: {order.EmployeeId}, 訂單金額: {order.Amount:C}");
            }

            /*
             * GroupBy 方法的使用說明：
             * 1. GroupBy(o => o.EmployeeId) - 按員工ID分組
             * 2. Select(...) - 對每個分組進行投影
             * 3. g.Key - 分組的鍵值（此例中是員工ID）
             * 4. g.Sum(...) - 計算該分組內所有項目的總和
             */
            var groupedOrders = orders
                .GroupBy(o => o.EmployeeId)                    // 按員工ID分組
                .Select(g => new                               // 投影每個分組
                {
                    EmployeeId = g.Key,                        // 分組鍵值
                    TotalAmount = g.Sum(o => o.Amount),        // 計算總金額
                    MaxAmount = g.Max(o => o.Amount),          // 計算最大金額
                    MinAmount = g.Min(o => o.Amount),          // 計算最小金額
                    AverageAmount = g.Average(o => o.Amount),  // 計算平均金額
                    OrderCount = g.Count()                     // 計算訂單數量
                });

            Console.WriteLine("\n按員工ID分組的統計結果:");
            foreach (var group in groupedOrders)
            {
                Console.WriteLine($"  員工ID: {group.EmployeeId}");
                Console.WriteLine($"    總金額: {group.TotalAmount:C}");
                Console.WriteLine($"    最大金額: {group.MaxAmount:C}");
                Console.WriteLine($"    最小金額: {group.MinAmount:C}");
                Console.WriteLine($"    平均金額: {group.AverageAmount:C}");
                Console.WriteLine($"    訂單數: {group.OrderCount} 筆");
                Console.WriteLine("    ---");
            }

            Console.WriteLine("\n方法語法說明:");
            Console.WriteLine("orders.GroupBy(o => o.EmployeeId).Select(g => new { ... })");
            Console.WriteLine("等同於查詢語法: from o in orders group o by o.EmployeeId into g select new { ... }");

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 3.1: 多鍵值分組查詢 (Group By - Multiple Keys)
        /// 展示如何使用複合鍵值進行分組，此時的鍵值變成一個物件類型
        /// </summary>
        public static void Exec31()
        {
            Console.WriteLine("=== 範例 3.1: 多鍵值分組查詢 ===");

            // 員工銷售資料 - 包含員工ID、姓名和銷售金額
            List<EmpSales> empSales = InitializeEmpSalesData();

            Console.WriteLine("員工銷售原始資料:");
            foreach (var sale in empSales)
            {
                Console.WriteLine($"  員工ID: {sale.EmployeeId}, 姓名: {sale.Name}, 銷售金額: {sale.Amount:C}");
            }

            /*
             * 複合鍵值分組說明：
             * 1. new { o.EmployeeId, o.Name } - 建立匿名類型作為分組鍵值
             * 2. GroupBy 會將具有相同 EmployeeId 和 Name 的項目分在同一組
             * 3. g.Key.EmployeeId 和 g.Key.Name - 存取複合鍵值的各個屬性
             */
            var groupedData = empSales
                .GroupBy(o => new { o.EmployeeId, o.Name })    // 按員工ID和姓名分組
                .Select(g => new                               // 投影每個分組
                {
                    EmployeeId = g.Key.EmployeeId,             // 存取複合鍵值的員工ID
                    Name = g.Key.Name,                         // 存取複合鍵值的姓名
                    TotalAmount = g.Sum(o => o.Amount),        // 計算該員工的總銷售金額
                    SalesCount = g.Count()                     // 計算該員工的銷售次數
                });

            Console.WriteLine("\n按員工ID和姓名分組的統計結果:");
            foreach (var item in groupedData)
            {
                Console.WriteLine($"  員工: {item.Name} (ID: {item.EmployeeId})");
                Console.WriteLine($"    總銷售金額: {item.TotalAmount:C}");
                Console.WriteLine($"    銷售次數: {item.SalesCount} 次");
                Console.WriteLine("    ---");
            }

            Console.WriteLine("\n複合鍵值分組說明:");
            Console.WriteLine("GroupBy(o => new { o.EmployeeId, o.Name })");
            Console.WriteLine("建立匿名類型 { EmployeeId, Name } 作為分組鍵值");
            Console.WriteLine("只有當 EmployeeId 和 Name 都相同時，才會被分在同一組");

            Console.WriteLine(); // 空行分隔
        }


        /// <summary>
        /// 範例 4: 內部聯接查詢 (Inner Join)
        /// 展示如何使用 Join 方法實現內部聯接，只返回兩個集合中都有匹配的資料
        /// </summary>
        public static void Exec4()
        {
            Console.WriteLine("=== 範例 4: 內部聯接查詢 (Inner Join) ===");

            // 員工資料
            List<Emp> emps = InitializeEmployees();
            Console.WriteLine("員工資料:");
            foreach (var emp in emps)
            {
                Console.WriteLine($"  {emp.EmployeeId} - {emp.Name}");
            }

            // 訂單資料
            List<OrderData> orders = InitializeOrderData();
            Console.WriteLine("\n訂單資料:");
            foreach (var order in orders)
            {
                Console.WriteLine($"  員工ID: {order.EmployeeId}, 金額: {order.Amount:C}");
            }

            /*
             * Join 方法參數說明：
             * 1. orders - 要聯接的第二個集合
             * 2. e => e.EmployeeId - 第一個集合的鍵值選擇器（員工集合）
             * 3. o => o.EmployeeId - 第二個集合的鍵值選擇器（訂單集合）
             * 4. (e, o) => new { ... } - 結果選擇器，定義聯接後的結果格式
             */

            var joinedData = emps
                .Join(
                    orders,                                    // 要聯接的第二個集合
                    e => e.EmployeeId,                        // 第一個集合的鍵值選擇器
                    o => o.EmployeeId,                        // 第二個集合的鍵值選擇器
                    (e, o) => new                             // 結果選擇器
                    {
                        e.EmployeeId,
                        e.Name,
                        o.Amount
                    });

            Console.WriteLine("\n內部聯接結果 (只顯示有訂單的員工):");
            foreach (var item in joinedData)
            {
                Console.WriteLine($"  員工: {item.Name} (ID: {item.EmployeeId}), 訂單金額: {item.Amount:C}");
            }

            Console.WriteLine("\n注意: 員工 004 (Allen) 沒有訂單，所以不會出現在內部聯接結果中");

            Console.WriteLine("\n方法語法說明:");
            Console.WriteLine("emps.Join(orders, e => e.EmployeeId, o => o.EmployeeId, (e,o) => new {...})");
            Console.WriteLine("等同於查詢語法: from e in emps join o in orders on e.EmployeeId equals o.EmployeeId select new {...}");

            Console.WriteLine(); // 空行分隔
        }

        /// <summary>
        /// 範例 4.1: 左外部聯接查詢 (Left Outer Join)
        /// 展示如何使用 GroupJoin + SelectMany + DefaultIfEmpty 實現左外部聯接
        /// 保留左側集合的所有記錄，即使右側沒有匹配的資料
        /// </summary>
        public static void Exec41()
        {
            Console.WriteLine("=== 範例 4.1: 左外部聯接查詢 (Left Outer Join) ===");

            List<Emp> emps = InitializeEmployees();
            List<OrderData> orders = InitializeOrderData();

            Console.WriteLine("注意: 員工 004 (Allen) 沒有任何訂單，但在左聯接中仍會顯示");

            /*
             * 左外部聯接的實現步驟：
             * 1. GroupJoin - 將右側匹配的項目分組
             * 2. DefaultIfEmpty - 為沒有匹配的項目提供預設值
             * 3. SelectMany - 展開分組結果
             * 
             * 參數說明：
             * - emp => emp.EmployeeId: 左側集合的鍵值選擇器
             * - order => order.EmployeeId: 右側集合的鍵值選擇器
             * - (emp, orderGroup) => new { ... }: 分組結果選擇器
             * orderGroup 是 IEnumerable<OrderData> 類型，代表對應到特定員工的所有訂單集合。
             * - DefaultIfEmpty(new OrderData { Amount = 0 }): 為空分組提供預設值
             */

            var leftJoinData = emps
                .GroupJoin(
                    orders,                                    // 要聯接的訂單集合
                    emp => emp.EmployeeId,                     // 員工集合的鍵值選擇器
                    order => order.EmployeeId,                 // 訂單集合的鍵值選擇器
                    (emp, orderGroup) => new                   // 分組結果選擇器
                    {
                        emp.EmployeeId,
                        emp.Name,
                        Orders = orderGroup.DefaultIfEmpty(new OrderData { EmployeeId = emp.EmployeeId, Amount = 0 })
                    })
                .SelectMany(                                   // 展開分組結果
                    x => x.Orders.Select(o => new
                    {
                        x.EmployeeId,
                        x.Name,
                        o.Amount
                    }));

            Console.WriteLine("\n左外部聯接結果 (所有員工都會顯示):");
            foreach (var item in leftJoinData)
            {
                string amountText = item.Amount == 0 ? "無訂單" : item.Amount.ToString("C");
                Console.WriteLine($"  員工: {item.Name} (ID: {item.EmployeeId}), 訂單金額: {amountText}");
            }

            Console.WriteLine("\n左外部聯接實現說明:");
            Console.WriteLine("1. GroupJoin: 將右側匹配的資料分組");
            Console.WriteLine("2. DefaultIfEmpty: 為沒有匹配的員工提供預設訂單");
            Console.WriteLine("3. SelectMany: 展開分組結果為平坦結構");
            Console.WriteLine("4. 結果: 所有員工都會顯示，沒有訂單的員工金額顯示為 0");

            Console.WriteLine(); // 空行分隔
        }

    }

}
