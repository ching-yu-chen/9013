﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// 學員資料類別
    /// </summary>
    internal class Student
    {
        public string StudentId { get; set; }               // 學員編號
        public string Name { get; set; }                    // 姓名
        public string Gender { get; set; }                  // 性別
        public DateTime Birthday { get; set; }              // 生日
        public string Address { get; set; }                 // 通訊地址
        public List<string> Emails { get; set; }            // 多筆電子郵件
        public List<string> Phones { get; set; }            // 多筆聯絡電話
        public List<CourseRecord> CourseRecords { get; set; } // 多筆選課紀錄

        public Student(string studentId, string name, string gender, DateTime birthday, string address)
        {
            StudentId = studentId;
            Name = name;
            Gender = gender;
            Birthday = birthday;
            Address = address;
            Emails = new List<string>();
            Phones = new List<string>();
            CourseRecords = new List<CourseRecord>();
        }

        public void AddEmail(string email) => Emails.Add(email);

        //public void AddEmail(string email)
        //{
        //    Emails.Add(email);  // 添加電子郵件
        //}

        public void AddPhone(string phone) => Phones.Add(phone);
        public void AddCourse(CourseRecord course) => CourseRecords.Add(course);

        public void Display()
        {
            Console.WriteLine($"學員編號: {StudentId}");
            Console.WriteLine($"姓名: {Name}, 性別: {Gender}, 生日: {Birthday:yyyy-MM-dd}");
            Console.WriteLine($"地址: {Address}");
            Console.WriteLine("電子郵件:");
            Emails.ForEach(e => Console.WriteLine($" - {e}"));

            //foreach (var email in Emails)
            //{
            //    Console.WriteLine($" - {email}");
            //}

            Console.WriteLine("聯絡電話:");
            Phones.ForEach(p => Console.WriteLine($" - {p}"));
            Console.WriteLine("選課記錄:");
            foreach (var c in CourseRecords)
            {
                Console.WriteLine($" - {c.CourseCode}: {c.CourseName}, {c.Hours} 小時, 地點：{c.Location}");
            }
        }

        public int GetAverageHours()
        {
            int total = 0;
            int count = 0;

            foreach (var course in CourseRecords)
            {
                total += course.Hours;
                count++;
            }

            if (count == 0)
                return 0;

            return (int)total / count;
        }

        public int GetAverageHours2()
        {
            if (CourseRecords.Count == 0) return 0;
            return (int)CourseRecords.Average(c => c.Hours); // 使用 LINQ 計算平均時數
        }

        public bool RemoveCourse(string courseCode)
        {
            for (int i = 0; i < CourseRecords.Count; i++)
            {
                if (CourseRecords[i].CourseCode == courseCode)
                {
                    CourseRecords.RemoveAt(i);
                    return true; // 成功移除
                }
            }
            return false; // 找不到對應課程代碼
        }

        //多載（Overload）
        /*
         * 同一個方法名稱，根據參數的「數量」、「型別」或「順序」不同，
         * 編譯器會自動選擇正確的方法版本來呼叫。
         */
        public bool RemoveCourse(CourseRecord course)
        {
            CourseRecords.Remove(course);
            return true;
        }

    }
}
