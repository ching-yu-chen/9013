﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace LearnCSharp.Models
{
    /// <summary>
    /// AES 對稱式加解密教學展示
    /// 
    /// 重點：
    /// - Key 金鑰：決定加密強度，請安全保存，勿硬編碼在程式碼（程式碼）中
    /// - IV 初始化向量：避免相同明文產生相同密文，應該為每次加密隨機產生
    /// - 預設模式：CBC、Padding：PKCS7、BlockSize：128
    /// - 編碼：示範採用 UTF8 將字串轉位元組
    /// </summary>
    internal static class AESDemo
    {
        /// <summary>
        /// 範例一：使用 AesManaged（.NET Framework 常見）
        /// 展示產生 Key/IV、加密成 Base64、再解密還原
        /// </summary>
        public static void Do()
        {
            var plaintext = @"人工智慧產生內容（AIGC）則是 AI 的一個特定應用領域，它專注於使用 AI 建立新的、原創的內容。這可以包括文字、圖片、音樂、影片等各種形式的內容。";

            using (var aes = new AesManaged())
            {
                // 產生隨機 Key 與 IV（每次 new 預設即會隨機）
                var key = aes.Key;
                var iv = aes.IV;

                Console.WriteLine("[教學] Key/IV 需安全保存（通常以 Base64 儲存或以金鑰管理系統保管）");
                Console.WriteLine($"Key(Base64): {Convert.ToBase64String(key)}");
                Console.WriteLine($"IV (Base64): {Convert.ToBase64String(iv)}");
                Console.WriteLine();

                // 加密 -> Base64
                var cipherBase64 = string.Empty;
                var data = Encoding.UTF8.GetBytes(plaintext); // 明文轉 byte[]
                using (var encryptor = aes.CreateEncryptor(key, iv))
                {
                    var cipherSource = encryptor.TransformFinalBlock(data, 0, data.Length); // 加密後byte[]
                    cipherBase64 = Convert.ToBase64String(cipherSource);
                }

                Console.WriteLine("====== Encryptor（密文 Base64）======");
                Console.WriteLine(cipherBase64);
                Console.WriteLine();

                // 解密 <- Base64
                var roundtrip = string.Empty; // 還原明文
                var cipher = Convert.FromBase64String(cipherBase64); // 從 Base64 還原 byte[]
                using (var decryptor = aes.CreateDecryptor(key, iv))
                {
                    var plainBytes = decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
                    roundtrip = Encoding.UTF8.GetString(plainBytes);
                }
                Console.WriteLine("====== Decryptor（還原明文）======");
                Console.WriteLine(roundtrip);
            }
        }

        /// <summary>
        /// 範例二：使用 Aes.Create（跨平台建議）
        /// 與 Do() 相同的流程，但透過 Aes.Create() 取得實作，適合新專案
        /// </summary>
        public static void Do2()
        {
            var plaintext = @"人工智慧產生內容（AIGC）則是 AI 的一個特定應用領域，它專注於使用 AI 建立新的、原創的內容。這可以包括文字、圖片、音樂、影片等各種形式的內容。";

            using (var aes = Aes.Create())
            {
                // 產生隨機 Key 與 IV（每次 new 預設即會隨機）
                var key = aes.Key;
                var iv = aes.IV;

                Console.WriteLine("[教學] Key/IV 需安全保存（通常以 Base64 儲存或以金鑰管理系統保管）");
                Console.WriteLine($"Key(Base64): {Convert.ToBase64String(key)}");
                Console.WriteLine($"IV (Base64): {Convert.ToBase64String(iv)}");
                Console.WriteLine();

                // 加密 -> Base64（與 Do() 相同風格：直接示範步驟，不抽離工具）
                var cipherBase64 = string.Empty;
                var data = Encoding.UTF8.GetBytes(plaintext); // 明文轉 byte[]
                using (var encryptor = aes.CreateEncryptor(key, iv))
                {
                    var cipherSource = encryptor.TransformFinalBlock(data, 0, data.Length); // 加密後 byte[]
                    cipherBase64 = Convert.ToBase64String(cipherSource);
                }

                Console.WriteLine("====== Encryptor（密文 Base64）======");
                Console.WriteLine(cipherBase64);
                Console.WriteLine();

                // 解密 <- Base64（直接示範還原流程）
                var roundtrip = string.Empty; // 還原明文
                var cipher = Convert.FromBase64String(cipherBase64); // 從 Base64 還原 byte[]
                using (var decryptor = aes.CreateDecryptor(key, iv))
                {
                    var plainBytes = decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
                    roundtrip = Encoding.UTF8.GetString(plainBytes);
                }

                Console.WriteLine("====== Decryptor（還原明文）======");
                Console.WriteLine(roundtrip);
            }
        }

    }
}
