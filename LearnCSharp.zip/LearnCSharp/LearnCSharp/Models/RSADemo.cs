﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// RSA 非對稱式加密教學展示
    /// 
    /// 重點：
    /// - 金鑰對（Public/Private）：公鑰加密、私鑰解密；或私鑰簽章、公鑰驗章
    /// - Padding：建議使用 OAEP（安全性高），避免舊式 PKCS#1 v1.5
    /// - 金鑰長度：建議至少 2048 bits（越長越安全，但速度較慢）
    /// - 用途：RSA 適合加密「短資料」與「金鑰交換」，不適合大檔案（改用 AES 並以 RSA 加密 AES Key）
    /// 
    /// 
    /// Padding 的作用是什麼
    /// - 在加密前先把明文「包成標準格式」，放入隨機數與固定結構。
    /// - 解密時先驗「包裝格式」是否正確；不對就統一丟掉（回同樣的錯誤），不給任何可用細節。
    /// - 因為有隨機數，同一份明文每次加密都長不一樣，攻擊者也無法比對樣本。
    /// - 防止結構化與可預測明文被直接映射成可被攻擊的密文（避免「裸 RSA」）。
    /// - 加入隨機性，避免同一明文每次加密得到相同密文（抗重放/字典攻擊）。
    /// - 提供基本的格式/一致性檢查，降低解密時被「錯誤回應」當作預言機濫用的風險。
    ///     * 攻擊者會一直丟各種「亂掉的密文」到你的系統，偷看系統回的錯誤差異（像是回應速度、錯誤訊息內容不同），
    ///     從這些差異一點一滴推回私鑰或明文。這種把系統「錯誤回應」當成線索來占卜的手法，就叫「預言機攻擊」。
    ///     * 想像你寄包裹到倉庫。若倉庫人員會說「這是尺寸錯」、「這是重量超標」、「這是地址錯」，攻擊者就能靠不同回覆推敲包裹內容。
    ///     * 如果倉庫只統一回「格式不對，拒收」，攻擊者就拿不到細節線索。
    /// - PKCS#1 v1.5：老派包裝法，歷史相容性好，但如果實作把錯誤差異外露，攻擊者較容易用來「占卜」。
    /// - OAEP：進化版包裝法，加入更嚴謹的隨機混擾與檢查，讓攻擊者就算一直亂丟密文，也只會拿到「統一的拒收」，更難推回任何有用資訊。
    /// - 安全性：OAEP > PKCS#1 v1.5（在實務與理論上皆較佳）
    /// - 相容性：PKCS#1 v1.5 較廣，但新系統應優先 OAEP
    /// - 明文可容納長度：PKCS#1 v1.5 略大；OAEP 隨雜湊越強，可容納越小
    /// - 一句話總結：Padding 就是把明文先「安全包裝」，讓解密端能「同一標準驗收、同一方式拒收」，不給攻擊者從錯誤差異中挖祕密的機會；而 OAEP 是比 PKCS#1 v1.5 更安全的包裝法。
    /// </summary>
    internal static class RSADemo
    {
        /// <summary>
        /// 範例一：使用 RSACryptoServiceProvider 與 XML 金鑰（相容 .NET Framework 傳統寫法）
        /// 使用 OAEP（SHA-1）進行加密/解密
        /// </summary>
        public static void LabBasicXml()
        {
            var plaintext = "輝達（NVIDIA）創辦人黃仁勳今（2）日於台大發表 keynote 演說";
            Console.WriteLine("================ 明文 =====================");
            Console.WriteLine(plaintext);

            // 建議 2048 bits 以上
            using (var rsa = new RSACryptoServiceProvider(2048))
            {
                var publicKeyXml = rsa.ToXmlString(false);  // 公鑰 XML
                var privateKeyXml = rsa.ToXmlString(true);  // 公私鑰 XML

                Console.WriteLine("\n=== 金鑰（XML）摘要 ===");
                Console.WriteLine($"Public XML length: {publicKeyXml.Length}");
                Console.WriteLine($"Private XML length: {privateKeyXml.Length}");
                Console.WriteLine($"Public XML: {publicKeyXml}");
                Console.WriteLine($"Private XML: {privateKeyXml}");

                // 使用公鑰加密（OAEP=true 代表 OAEP-SHA1 於 RSACryptoServiceProvider）
                // 1) 明文轉位元組
                var data = Encoding.UTF8.GetBytes(plaintext);
                // 2) 用公鑰建立 RSA 物件進行加密
                string cipherBase64;
                using (var rsaEnc = new RSACryptoServiceProvider())
                {
                    rsaEnc.FromXmlString(publicKeyXml);
                    var cipher = rsaEnc.Encrypt(data, fOAEP: true);
                    cipherBase64 = Convert.ToBase64String(cipher);
                }
                Console.WriteLine("\n====== 密文（Base64）======");
                Console.WriteLine(cipherBase64);

                // 使用私鑰解密
                string roundtrip;
                using (var rsaDec = new RSACryptoServiceProvider())
                {
                    rsaDec.FromXmlString(privateKeyXml);
                    var cipherBytes = Convert.FromBase64String(cipherBase64);
                    var plainBytes = rsaDec.Decrypt(cipherBytes, fOAEP: true);
                    roundtrip = Encoding.UTF8.GetString(plainBytes);
                }
                Console.WriteLine("\n====== 解密還原（明文）======");
                Console.WriteLine(roundtrip);

                // 補充：最大可加密長度（與金鑰與 Padding 相關）
                // OAEP-SHA1 的可加密最大位元組數 = keyBytes - (2 * 20 + 2)
                int keyBytes = 2048 / 8; // 2048-bit 金鑰 = 256 bytes
                int maxLen = keyBytes - (2 * 20 + 2); // 256 - 42 = 214 bytes
                Console.WriteLine($"\n[教學] 2048-bit + OAEP(SHA-1) 最大可加密位元組數：約 {maxLen} bytes");
            }
        }

        /// <summary>
        /// 範例二：使用 RSA.Create 與 RSAEncryptionPadding（建議的新式用法）
        /// 優先嘗試 OAEP-SHA256，不支援時退回 OAEP-SHA1
        /// </summary>
        public static void LabModernPadding()
        {
            var plaintext = "這是使用 RSA.Create() + OAEP 的加密示範";

            using (var rsa = RSA.Create())
            {
                rsa.KeySize = 2048; // 建議 2048 bits 以上

                // 匯出/匯入參數示範：並輸出 XML 金鑰（教學用途，便於觀察結構）
                var privateParams = rsa.ExportParameters(includePrivateParameters: true);
                var publicParams = rsa.ExportParameters(includePrivateParameters: false);


                // 將參數匯入 RSACryptoServiceProvider，以輸出 XML 金鑰（公鑰/含私鑰）
                string publicKeyXmlModern;
                string privateKeyXmlModern;
                using (var rsaXml = new RSACryptoServiceProvider())
                {
                    rsaXml.ImportParameters(publicParams);
                    publicKeyXmlModern = rsaXml.ToXmlString(false);

                    rsaXml.ImportParameters(privateParams);
                    privateKeyXmlModern = rsaXml.ToXmlString(true);
                }

                Console.WriteLine("\n=== 金鑰（XML）展示（現代 API 取得參數 → 以 XML 呈現） ===");
                Console.WriteLine("(XML 長度摘要) Public: " + publicKeyXmlModern.Length + ", Private: " + privateKeyXmlModern.Length);
                Console.WriteLine("-- Public Key (XML) --");
                Console.WriteLine(publicKeyXmlModern);
                Console.WriteLine("-- Private Key (XML) [教學用途示範，請勿在正式環境外洩] --");
                Console.WriteLine(privateKeyXmlModern);

                // 以 XML 金鑰 + RSACryptoServiceProvider 進行加/解密（OAEP-SHA1）
                // 說明：RSACryptoServiceProvider 的 OAEP 僅支援 SHA-1，因此此處 Padding 固定為 OAEP-SHA1
                int keyBytes = rsa.KeySize / 8;
                int maxBytes = keyBytes - (2 * 20 + 2); // OAEP-SHA1 最大明文位元組數

                Console.WriteLine("\n=== Padding 與金鑰資訊 ===");
                Console.WriteLine($"KeySize: {rsa.KeySize} bits");
                Console.WriteLine("Padding: OAEP-SHA1 (XML/RSACryptoServiceProvider)");
                Console.WriteLine($"Max encrypt bytes (approx): {maxBytes}");

                // 加密（使用公鑰 XML + OAEP-SHA1）
                var plainBytes = Encoding.UTF8.GetBytes(plaintext);
                string cipherBase64;
                using (var rsaEnc = new RSACryptoServiceProvider())
                {
                    rsaEnc.FromXmlString(publicKeyXmlModern);
                    var cipher = rsaEnc.Encrypt(plainBytes, fOAEP: true);
                    cipherBase64 = Convert.ToBase64String(cipher);
                }
                Console.WriteLine("\n====== 密文（Base64）======");
                Console.WriteLine(cipherBase64);

                // 解密（使用私鑰 XML + OAEP-SHA1）
                string roundtrip;
                using (var rsaDec = new RSACryptoServiceProvider())
                {
                    rsaDec.FromXmlString(privateKeyXmlModern);
                    var cipherBytes = Convert.FromBase64String(cipherBase64);
                    var decrypted = rsaDec.Decrypt(cipherBytes, fOAEP: true);
                    roundtrip = Encoding.UTF8.GetString(decrypted);
                }
                Console.WriteLine("\n====== 解密還原（明文）======");
                Console.WriteLine(roundtrip);
            }
        }

    }
}
