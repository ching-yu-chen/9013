﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    public class GenericLab
    {
        public void ProcessItem<T>(T item)
        {
            if (item is int)
            {
                ProcessInt((int)(object)item);
            }
            else if (item is string)
            {
                ProcessString(item as string);
            }
            else if (item is Student)
            {
                ProcessStudent(item as Student);
            }
            else
            {
                Console.WriteLine("未知型別的處理方式");
            }
        }

        private void ProcessInt(int item)
        {
            Console.WriteLine($"處理整數: {item}");
        }

        private void ProcessString(string item)
        {
            Console.WriteLine($"處理字串: {item}");
        }

        private void ProcessStudent(Student item)
        {
            Console.WriteLine($"處理學生: Name = {item.Name}, Gender = {item.Gender}");
        }
    }
}
