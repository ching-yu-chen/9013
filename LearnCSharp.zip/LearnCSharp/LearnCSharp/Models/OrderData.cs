﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    /// <summary>
    /// 訂單資料模型
    /// </summary>
    public class OrderData
    {
        public string EmployeeId { get; set; }
        public int Amount { get; set; }

        public override string ToString()
        {
            return $"員工ID: {EmployeeId}, 訂單金額: {Amount:C}";
        }
    }

    /// <summary>
    /// 員工資料模型
    /// </summary>
    public class Emp
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return $"員工ID: {EmployeeId}, 姓名: {Name}";
        }
    }

    /// <summary>
    /// 員工銷售資料模型
    /// </summary>
    public class EmpSales
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public int Amount { get; set; }

        public override string ToString()
        {
            return $"員工: {Name} (ID: {EmployeeId}), 銷售金額: {Amount:C}";
        }
    }

}
