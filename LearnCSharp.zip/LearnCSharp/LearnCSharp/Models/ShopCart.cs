﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    internal class ShopCart
    {
        private List<Product> products;

        public ShopCart()
        {
            products = new List<Product>();
        }

        public void AddProduct(Product product)
        {
            products.Add(product);
            // 在這裡添加商品到購物車
            Console.WriteLine($"商品 {product.Name} 已添加到購物車。");
        }

        public void DisplayCart()
        {
            Console.WriteLine("購物車中的商品:");
            foreach (var product in products)
            {
                product.Display();
            }
        }

    }

    public static class CartUtils
    {
        /// <summary>
        /// 計算折扣後的金額
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="percent"></param>
        /// <returns></returns>
        public static int CalculateDiscount(int amount, decimal percent)
        {
            return (int)(amount * (1 - percent));
        }
    }
}
