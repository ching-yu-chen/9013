﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnCSharp.Models
{
    internal static class AppConfig
    {
        public static string DbConnectString { get; set; }
        public static string ApiBaseUrl { get; set; }
    }
}
