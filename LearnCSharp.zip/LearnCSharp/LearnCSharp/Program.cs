﻿using LearnCSharp.Models;
using LearnCSharp.Models.OopInheritance;
using System.Net;
using System.Xml.Linq;

namespace LearnCSharp
{
    internal class Program
    {
        static async Task Main(string[] args)
        {

            Console.WriteLine("Hello, World!");

            LinqDemo.Run2();


            //File.AppendAllLinesAsync("log.txt", new string[] { $"Hello, World! {DateTime.Now}" });


            //Console.WriteLine($"Start Time : {DateTime.Now}");
            //var coffice = AsyncDemoModel.CoffeeAsync();
            //var eggs = AsyncDemoModel.EggsAsync();
            //var bread = AsyncDemoModel.BreadAsync();
            //await coffice;
            //await eggs;
            //await bread;
            //Console.WriteLine($"End Time : {DateTime.Now}");


            //Console.WriteLine($"Start Time : {DateTime.Now}");
            //var coffice = AsyncDemoModel.CoffeeAsync();
            //await coffice;
            //var eggs = AsyncDemoModel.EggsAsync();
            //await eggs;
            //var bread = AsyncDemoModel.BreadAsync();
            //await bread;
            //Console.WriteLine($"End Time : {DateTime.Now}");



            //Console.WriteLine("Start : "+DateTime.Now);
            //SyncDemoModel.Coffee();
            //SyncDemoModel.Eggs();
            //SyncDemoModel.Bread();
            //Console.WriteLine("End : " + DateTime.Now);




            //RsaMixAesDemo.Do();

            //RSADemo.LabBasicXml();
            //RSADemo.LabModernPadding();
            //AESDemo.Do2();

            //Base64Demo.Do("Hello, World!");
            //Console.WriteLine("\n\n");
            //Base64Demo.Do("賽 後葉君璋總教練點評2名洋投，「龍聖看起來還可以，就是控球還是差一點，至於新洋投鎛銳，看得出來他是真的是還蠻有經驗的，不管控球和各方面，及他對於比賽的狀況，其實掌握得蠻好的，我覺得才有機會拿下這場勝利」。");
            //HashDemo.PwdPBKDF2Hash("123");
            //HashDemo.SHA512Demo("賽 後葉君璋總教練點評2名洋投，「龍聖看起來還可以，就是控球還是差一點，至於新洋投鎛銳，看得出來他是真的是還蠻有經驗的，不管控球和各方面，及他對於比賽的狀況，其實掌握得蠻好的，我覺得才有機會拿下這場勝利」。");

            //DirectoryInfoAccess.Exec();

            //try
            //{
            //    var e1 = new ErrorDemo1();
            //    e1.Method();

            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine($"Message:{e.Message}");
            //    Console.WriteLine($"StackTrace:{e.StackTrace}");
            //    Console.WriteLine($"String:{e.ToString()}");
            //    Console.WriteLine($"系統發生異常");
            //    //throw;
            //}
            //finally
            //{
            //    Console.WriteLine($"不管有沒有錯誤都會執行");
            //}



            //var lab = new GenericLab();

            //// 處理整數
            //lab.ProcessItem(123);
            //lab.ProcessItem<int>(123);

            //// 處理字串
            //lab.ProcessItem("Hello, World!");
            //lab.ProcessItem<string>("Hello, World!");

            //// 處理學生物件
            //Models.Student student = new Models.Student("001", "小明", "男", DateTime.Parse("1995/5/15"), "高雄市三民區");
            //lab.ProcessItem(student);
            //lab.ProcessItem<Models.Student>(student);

            //// 處理未知型別
            //lab.ProcessItem(45.67);
            //lab.ProcessItem<decimal>(45.67m);




            //var c1 = new PhysicalCourse("C101", "C# 程式設計", 30, DateTime.Parse("2025/7/5"), "台北教室 A");
            //Console.WriteLine(c1.Describe());

            //var c2 = new OnlineVideoCourse("C102", "SQL 資料庫設計", 20, "線上平台 B");

            //var cList = new List<CourseBase>();
            //cList.Add(c1);
            //cList.Add(c2);


            //foreach (var course in cList)
            //{
            //    Console.WriteLine("==================Start====================");
            //    Console.WriteLine(course.Describe());
            //    Console.WriteLine(course.GetType().Name);

            //    Console.WriteLine("\n\n");


            //    Console.WriteLine(((CourseBase)course).Describe());
            //    Console.WriteLine(((CourseBase)course).GetType().Name);
            //}


            //var s1 = new LearnCSharp.Models.OopInheritance.Student("Ian", "ian@mail.com", "012345678", "AI");
            //s1.AddLearn("C# 基礎");


            //var p = new Personal("Wang", 1.75, 70);
            //var bmiCalculator = new BmiCalculator();
            ////Console.WriteLine($"Name: {p.Name}, H: {p.Height} m, W: {p.Weight} kg");
            ////double bmi = bmiCalculator.CalculateBMI(p);
            ////Console.WriteLine($"After Name: {p.Name}, H: {p.Height} m, W: {p.Weight} kg");

            //Console.WriteLine($"\n\n");


            //var h = p.Height;
            //var w = p.Weight;
            ////Console.WriteLine($"Name: {p.Name}, H: {h} m, W: {w} kg");
            ////double bmi3 = bmiCalculator.CalculateBMI(ref h, ref w);
            ////Console.WriteLine($"After Name: {p.Name}, H: {h} m, W: {w} kg");

            ////可選擇性參數
            //double bmi2 = bmiCalculator.CalculateBMI(h, w);

            //double bmi4 = bmiCalculator.CalculateBMI(h, w, true);

            ////具名參數
            //double bmi5 = bmiCalculator.CalculateBMI(weight: w, height: h);

            ////傳出參數
            //var bmiDesc = string.Empty;
            //double bmi6 = bmiCalculator.CalculateBMI(h, w, out bmiDesc);
            //Console.WriteLine($"BMI: {bmi6}, Description: {bmiDesc}");
            //int.TryParse("123", out int result);
            //Console.WriteLine($"Parsed result: {result}");


            //List<Student> students = new List<Student>();
            //var c1 = new CourseRecord("C101", "C#", 20, "線上");
            //var c2 = new CourseRecord("C102", "SQL", 15, "教室 A");
            //var c3 = new CourseRecord("C103", "Python", 18, "線上");

            //// 建立 5 位學生並加入選課紀錄
            //var s1 = new Student("S001", "小明", "男", new DateTime(1995, 5, 15), "高雄市三民區");
            //s1.AddCourse(c1);
            //s1.AddCourse(c2);
            //s1.RemoveCourse(c1); // 假設小明不再選擇 C# 課程
            //s1.RemoveCourse("C101");
            //students.Add(s1);

            //var s2 = new Student("S002", "小華", "女", new DateTime(1996, 2, 2), "高雄市新興區");
            //s2.AddCourse(c2);
            //s2.AddCourse(c3);
            //students.Add(s2);

            //var s3 = new Student("S003", "小美", "女", new DateTime(1995, 8, 17), "高雄市三民區");
            //s3.AddCourse(c3);
            //students.Add(s3);

            //var s4 = new Student("S004", "阿強", "男", new DateTime(1995, 6, 24), "高雄市左營區");
            //s4.AddCourse(c2);
            //s4.AddCourse(c3);
            //students.Add(s4);

            //var s5 = new Student("S005", "小芸", "女", new DateTime(1995, 4, 3), "高雄市前鎮區");
            //s5.AddCourse(c1);
            //s5.AddCourse(c2);
            //students.Add(s5);

            //// 輸出每位同學的平均上課時數
            //Console.WriteLine("各同學平均上課時數：\n");
            //foreach (var student in students)
            //{
            //    var avg = student.GetAverageHours();
            //    Console.WriteLine($"學員: {student.Name}, 平均上課時數: {avg} 小時");
            //}



            //var student = new Student("S001", "王大明", "男", new DateTime(1995, 5, 15), "高雄市三民區");

            //student.AddEmail("wang1@example.com");
            //student.AddEmail("wang2@gmail.com");

            //student.AddPhone("0912345678");
            //student.AddPhone("0712345678");

            //student.AddCourse(new CourseRecord("C101", "C# 程式設計", 30, "線上"));
            //student.AddCourse(new CourseRecord("C102", "資料庫設計", 20, "台南認證中心"));

            //student.Display();

        }
    }
}
